/*---

General:
	<TableName> 			(Recommended: Product/Use Case Name)
	<ProcedureCodeList> 	(Replace with comma separated CPT, PCS list)
	<NDCList> 				(Replace with comma separated NDC list)
	<StartYear>


For Drug Use Case:
	--drug 					(Replace complete string with blank)
	


---*/

--------------------------------------NDC/Procedure Details--------------------------------
create or replace table sandbox.<TableName>_1 as
select distinct claim_number as claim_no,
	ndc,
	procedure as proc_code,
	procedure_type as proc_type,
	line_number as line_no,
	line_charge as charge_amt,
	rendering_provider_npi as physician_npi,
	place_service as pos,
	coalesce(pr.service_from, pr.statement_from) as event_date,
	procedure_modifier_1 as mod1,
	procedure_modifier_2 as mod2,
	procedure_modifier_3 as mod3,
	procedure_modifier_4 as mod4,
	case 
		when data_source = 'ALBATROSS' then 'Albatross'
		when data_source = 'CONDOR' then 'Condor'
		when data_source = 'OSPREY' then 'Osprey'
		when data_source = 'VULTURE' then 'Vulture'
		else null end as source
from raven_claims_submits_procedure pr
where
	/*--- Enter start year ---*/
	year(coalesce(pr.service_from, pr.statement_from)) >= <StartYear> - 1
	/*--- Enter procedure code list and NDC list ---*/
	and (
		upper(procedure) in (<ProcedureCodeList>)
		or ndc in (<NDCList>)
		)
	/*--- Exclude records with no claim number ---*/
	and claim_number is not null
	and upper(claim_number) not like 'NULL';

------------------------Add Submit Header Details--------------------------------
create or replace table sandbox.<TableName>_2 as
select t1.*, 
	sh.encrypted_key_1,
	sh.encrypted_key_2,
	sh.type_bill as typebill,
	sh.total_charge as total_amt,
	sh.claim_type_code as claim_type
from sandbox.<TableName>_1 t1
inner join
	raven_claims_submits_header sh 
	on t1.claim_no = sh.claim_number
where
	/*--- Exclude records with no patient suffix ---*/
	sh.encrypted_key_1 is not null
	and upper(sh.encrypted_key_1) not like 'NULL'
	and upper(sh.encrypted_key_1) not like ('XXX%')
	and sh.encrypted_key_1 not in ('05ee833bcf5cc0c6981275ddb2e713c56db7d80c86427d731e633b086b974f35',	'94712e3eecd68c4d9299d95526150a89901d3f80ca66531378ecc193d9321aaa'
    ,	'6338da51e06496b3e86724cb21d02e1a496fbf9e5aad4ccda2e74ad280272a52',	'2ee9cd5d96d6717012be7aa605e8473198e9a35a5b66bdc2b126882feee4c034'
    ,	'd6b9c9b87d62f2680d225bd069b97a5235211e7b468082d415a34fede1ff3b15')
	and sh.encrypted_key_1 <> ''
	and sh.encrypted_key_2 is not null
	and upper(sh.encrypted_key_2) not like 'NULL'
	and upper(sh.encrypted_key_2) not like ('XXX%')
	and sh.encrypted_key_2 not in ('05ee833bcf5cc0c6981275ddb2e713c56db7d80c86427d731e633b086b974f35',	'94712e3eecd68c4d9299d95526150a89901d3f80ca66531378ecc193d9321aaa'
    ,	'6338da51e06496b3e86724cb21d02e1a496fbf9e5aad4ccda2e74ad280272a52',	'2ee9cd5d96d6717012be7aa605e8473198e9a35a5b66bdc2b126882feee4c034'
    ,	'd6b9c9b87d62f2680d225bd069b97a5235211e7b468082d415a34fede1ff3b15')
	and sh.encrypted_key_2 <> '';

------------------------Add Payer Details--------------------------------
/*----------Changes required
1. payer_sequence field will be added in de-duplication step to get primary payer
----------*/
create or replace table sandbox.<TableName>_3 as
select t2.*,
	sp.type_coverage as sourceofpayment,
	case 
		when upper(trim(type_coverage)) in ('16', 'MA', 'MB', '2', 'C', 'U', 'MPD')
			then 'Medicare'
		when upper(trim(type_coverage)) in ('MC', 'D', 'MED', 'MCM')
			then 'Medicaid'
		when upper(trim(type_coverage)) in ('CI', 'F', 'COM')
			then 'Commercial'
		else 'Other'
		end as ins_type,
	--Only Vulture and Osprey have payer_sequence value. For Albatross and Condor, this value is NULL
	sp.payer_sequence,
	sp.process_date
from sandbox.<TableName>_2 t2
inner join 
	raven_claims_submits_payer sp 
	on t2.claim_no = sp.claim_number;

------------------------Add Provider Details--------------------------------
/*----------Changes required
1. Add provider_type to fetch rendering, attending, supervising, operating, service location, etc. NPIs 
2. Coalesce rendering_provider_npi(coming from procedure table) with other physician NPIs
3. Coalesce service location NPIs per claim_no to get facility NPI
4. Filter for entity_type_code = 1 for physician, and 2 for facility
5. De-duplicate table to get one physician and facility NPI for each claim
----------*/
create or replace table sandbox.<TableName>_4 as
select t3.*,
	provider_npi as npi,
	provider_type,
	entity_type_code
from sandbox.<TableName>_3 t3
inner join 
	raven_claims_submits_provider pv
	on t3.claim_no = pv.claim_number; 
	
------------------------Add Rx Data--------------------------------	
/*-------Changes required
1. Ask Remy about mapping: Osprey raw data does not have a type_of_payment field - all values will be NULL
---------*/
--drug  create or replace table sandbox.<TableName>_5 as
--drug  select distinct 
--drug 	encrypted_key_1,
--drug 	encrypted_key_2,
--drug 	claim_number,
--drug 	product_or_service_id,
--drug 	prescriber_id,
--drug 	service_provider_id, 
--drug	national_provider_id,
--drug	response_code,
--drug 	date_of_service, 
--drug	date_authorized, 
--drug	date_prescription_written,
--drug 	data_source,
--drug 	type_of_payment,
--drug 	gross_amount_due_submitted
--drug  from
--drug 	raven_pharmacy rx
--drug 	/*--- Enter NDC list ---*/
--drug 	where 
--drug 		product_or_service_id in (<NDCList>);

------------------------Refine Rx Data--------------------------------	

--drug  create or replace table sandbox.<TableName>_6 as
--drug  select distinct 
--drug 	encrypted_key_1,
--drug 	encrypted_key_2,
--drug 	claim_number as claim_no,
--drug 	NULL as line_no,
--drug 	NULL as proc_code,
--drug 	NULL as proc_type,
--drug 	NULL as mod1,
--drug 	NULL as mod2,
--drug 	NULL as mod3,
--drug 	NULL as mod4,
--drug 	cast(product_or_service_id as varchar(5000)) as ndc,
--drug 	cast(prescriber_id as varchar(20000)) as physician_npi,
--drug 	cast(coalesce(service_provider_id, national_provider_id) as varchar(20000)) as facility_npi,
--drug 	cast(coalesce(date_of_service, date_authorized, date_prescription_written) as date) as event_date,
--drug 	case
--drug 		when upper(data_source) = 'CONDOR' 
--drug			then 'CondorRx'
--drug 		when upper(data_source) = 'OSPREY' 
--drug			then 'OspreyRx'
--drug		else null
--drug		end as source,
--drug 	cast(type_of_payment as varchar(2000)) as sourceofpayment,
--drug 	case 
--drug 		when upper(trim(type_of_payment)) = 'MPD'
--drug 			then 'Medicare'
--drug 		when upper(trim(type_of_payment)) in ('MED', 'MCM')
--drug 			then 'Medicaid'
--drug 		when upper(trim(type_of_payment)) in ('COM')
--drug 			then 'Commercial'
--drug 		else 'Other'
--drug 		end as ins_type,
--drug 	NULL as typebill,	
--drug 	NULL as pos,
--drug 	cast(gross_amount_due_submitted as float()) as charge_amt,
--drug 	cast(gross_amount_due_submitted as float()) as total_amt,
--drug 	NULL claim_type,
--drug 	event_date as process_date
--drug  from
--drug 	sandbox.<TableName>_5
--drug  where year(event_date) >= <StartYear> - 1
--drug 	/*--- Exclude records with no claim number ---*/
--drug 	and claim_number is not null
--drug 	and upper(claim_number) not like 'NULL'
--drug 	/*--- Exclude records with no patient suffix ---*/
--drug 	and encrypted_key_1 is not null
--drug	and upper(encrypted_key_1) not like 'NULL'
--drug	and upper(encrypted_key_1) not like 'XXX%'
--drug	and encrypted_key_1 not in ('05ee833bcf5cc0c6981275ddb2e713c56db7d80c86427d731e633b086b974f35',	'94712e3eecd68c4d9299d95526150a89901d3f80ca66531378ecc193d9321aaa'
--drug	,	'6338da51e06496b3e86724cb21d02e1a496fbf9e5aad4ccda2e74ad280272a52',	'2ee9cd5d96d6717012be7aa605e8473198e9a35a5b66bdc2b126882feee4c034'
--drug	,	'd6b9c9b87d62f2680d225bd069b97a5235211e7b468082d415a34fede1ff3b15')
--drug	and encrypted_key_2 is not null
--drug	and upper(encrypted_key_2) not like 'NULL'
--drug	and upper(encrypted_key_2) not like 'XXX%'
--drug	and encrypted_key_2 not in ('05ee833bcf5cc0c6981275ddb2e713c56db7d80c86427d731e633b086b974f35',	'94712e3eecd68c4d9299d95526150a89901d3f80ca66531378ecc193d9321aaa'
--drug	,	'6338da51e06496b3e86724cb21d02e1a496fbf9e5aad4ccda2e74ad280272a52',	'2ee9cd5d96d6717012be7aa605e8473198e9a35a5b66bdc2b126882feee4c034'
--drug	,	'd6b9c9b87d62f2680d225bd069b97a5235211e7b468082d415a34fede1ff3b15')
--drug	and encrypted_key_2 <> ''
--drug  and lower(trim(response_code)) = 'p';

------------------------Align Medical Fields--------------------------------
create or replace table sandbox.<TableName> as
select distinct encrypted_key_1,
	encrypted_key_2,
	claim_no,
	line_no,
	proc_code,
	proc_type,
	mod1,
	mod2,
	mod3,
	mod4,
	ndc,
	physician_npi,
	facility_npi,
	event_date,
	source,
	sourceofpayment,
	ins_type,
	typebill,
	pos,
	charge_amt,
	total_amt,
	claim_type,
	process_date
from sandbox.<TableName>_4;

------------------------Connect Medical and Rx Data--------------------------------	

--drug  create or replace table sandbox.<TableName> as
--drug  select distinct encrypted_key_1,
--drug	encrypted_key_2,
--drug	claim_no,
--drug	line_no,
--drug	proc_code,
--drug	proc_type,
--drug	mod1,
--drug	mod2,
--drug	mod3,
--drug	mod4,
--drug	ndc,
--drug	physician_npi,
--drug	facility_npi,
--drug	event_date,
--drug	source,
--drug	sourceofpayment,
--drug	ins_type,
--drug	typebill,
--drug	pos,
--drug	charge_amt,
--drug	total_amt,
--drug	claim_type,
--drug	process_date 
--drug	from sandbox.<TableName>
--drug  union all 
--drug  select distinct encrypted_key_1,
--drug	encrypted_key_2,
--drug	claim_no,
--drug	line_no,
--drug	proc_code,
--drug	proc_type,
--drug	mod1,
--drug	mod2,
--drug	mod3,
--drug	mod4,
--drug	ndc,
--drug	physician_npi,
--drug	facility_npi,
--drug	event_date,
--drug	source,
--drug	sourceofpayment,
--drug	ins_type,
--drug	typebill,
--drug	pos,
--drug	charge_amt,
--drug	total_amt,
--drug	claim_type,
--drug	process_date 
--drug	from  sandbox.<TableName>_6

;
/*-- Add and update date parts --*/
alter table sandbox.<TableName> add column year varchar(2000);

update sandbox.<TableName>
set year = cast(year(event_date) as varchar(2000));

alter table sandbox.<TableName> add column quarter varchar(2000);

update sandbox.<TableName>
set quarter = cast(quarter(event_date) as varchar(2000));

alter table sandbox.<TableName> add column year_month varchar(2000);

update sandbox.<TableName>
set year_month = to_varchar(event_date::timestamp, 'yyyymm');

/*--- Update point of care type ---*/
alter table sandbox.<TableName> add column pointofcaretype varchar(2000);
alter table sandbox.<TableName> add column claim_type_modified varchar(2000);


update sandbox.<TableName> a
set pointofcaretype = pos_name
from sandbox.rc_pos b
where trim(a.claim_type) = 'P'
and trim(a.pos) = trim(b.pos_code)
and pos_desc is not null;

update sandbox.<TableName> a
set pointofcaretype = pos_name
from sandbox.rc_pos b
where trim(left (a.typebill,2)) = trim(b.pos_code)
and source = 'Vulture'
and trim(a.claim_type) = 'P'
and (pos is NULL or upper(trim(pos)) = 'NULL')
and typebill is not NULL
and pointofcaretype is NULL;

update sandbox.<TableName> a
set pointofcaretype = desc
from sandbox.rc_type_bill b
where (trim(a.claim_type) = 'I'
or trim(a.claim_type_modified) = 'I')
and trim(left (a.typebill,2)) = trim(b.type_bill);

update sandbox.<TableName> a
set pointofcaretype = 'Pharmacy'
where source = 'CondorRx';

update sandbox.<TableName> a
set pointofcaretype = 'Pharmacy'
where source = 'OspreyRx';


/*--- De-duplicate records with same patsuffix, ndc, procedure and event_date within each source---*/
/*----------Changes required
1. payer_sequence field will be added in de-duplication step to get primary payer
------------*/
create or replace table sandbox.<TableName>_V1 as
	with a_cte as (
			select *,
				row_number() over (
					partition by source,
					encrypted_key_1, 
					encrypted_key_2,
					event_date,
					ndc,
					proc_code,
					mod1,
					mod2,
					mod3,
					mod4 order by source,
						encrypted_key_1, 
						encrypted_key_2,
						event_date,
						ndc,
						proc_code,
						mod1,
						mod2,
						mod3,
						mod4,
						claim_no desc						
					) as rr
			from sandbox.<TableName>
			)

select *
from a_cte
where rr = 1
and year(event_date) <= 2018;


/*-- Separate data from <StartYear> for overall trend analysis --*/
create or replace table sandbox.<TableName>_V2 as
select *
from sandbox.<TableName>_V1
where year >= <StartYear>
and year <= 2018;

----------------------------------------------------DE-DUPLICATE AND UPDATE FIELDS------------------------------------------------------------
  
/*--- De-duplicate records with same patsuffix, ndc, procedure and event_date ---*/
/*----------Changes required
1. payer_sequence field will be added in de-duplication step to get primary payer
------------*/
create or replace table sandbox.<TableName>_D1 as
	with a_cte as (
			select *,
				row_number() over (
					partition by encrypted_key_1, 
					encrypted_key_2,
					event_date,
					ndc,
					proc_code,
					mod1,
					mod2,
					mod3,
					mod4 order by encrypted_key_1, 
						encrypted_key_2,
						event_date,
						ndc,
						proc_code,
						mod1,
						mod2,
						mod3,
						mod4,
						claim_no desc
					) as rr
			from sandbox.<TableName>
			)

select *
from a_cte
where rr = 1
and year(event_date) <= 2018;


/*-- Separate data from <StartYear> for overall trend analysis --*/
create or replace table sandbox.<TableName>_D2 as
select *
from sandbox.<TableName>_D1
where year >= <StartYear>
and year <= 2018;

------------------------Drop Original Tables----------------------------------
/*---------Changes required
1. Any reason for dropping these tables? Probably we would need them for follow up analysis.
-----------*/
drop table if exists sandbox.<TableName>_1;
drop table if exists sandbox.<TableName>_2;
drop table if exists sandbox.<TableName>_3;
drop table if exists sandbox.<TableName>_4;
drop table if exists sandbox.<TableName>_5;
drop table if exists sandbox.<TableName>_6;


	
-----------------------------------------------------COUNTS--------------------------------------------------------

/*--- Overall, Quarterly Patient/Claim Count ---*/
select source,
	period,
	patvol,
	claimvol
from (
	select 'All' as source,
		'000' as year,
		'Overall' as period,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_D2

	union all
	
	select source,
		'000' as year,
		'Overall' as period,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_V2
	group by source
	
	union all
	
	select 'All' as source,
		year as year,
		'Q' || quarter || '-' || year as period,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_D2
	group by year,
		'Q' || quarter || '-' || year
	
	union all
	
	select source,
		year as year,
		'Q' || quarter || '-' || year as period,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_V2
	group by year,
		'Q' || quarter || '-' || year,
		source
	)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	year,
	period
;	


	
/*--- Monthly - Patient/Claim Counts ---*/
select source,
	period,
	patvol,
	claimvol
from (
	select 'All' as source,
		year as year,
		month(event_date) as month,
		month(event_date) || '-' || year as period,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_D2
	group by year,
		month,
		month(event_date) || '-' || year
	
	union all
	
	select source,
		year as year,
		month(event_date) as month,
		month(event_date) || '-' || year as period,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_V2
	group by year,
		month,
		month(event_date) || '-' || year,
		source
	)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	year,
	month,
	period
;	

	
/*--- Overall, Quarterly Physician/Facility Counts ---*/
select source,
	period,
	phyvol,
	facvol
from (
	select 'All' as source,
		'000' as year,
		'Overall' as period,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol
	from sandbox.<TableName>_D2
	
	union all
	
	select source,
		'000' as year,
		'Overall' as period,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol
	from sandbox.<TableName>_V2
	group by source
	
	union all
	
	select 'All' as source,
		year as year,
		'Q' || quarter || '-' || year as period,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol
	from sandbox.<TableName>_D2
	group by year,
		'Q' || quarter || '-' || year
	
	union all
	
	select source,
		year as year,
		'Q' || quarter || '-' || year as period,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol
	from sandbox.<TableName>_V2
	group by year,
		'Q' || quarter || '-' || year,
		source
	)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	year,
	period
;	

	
/*--- Monthly - Physician/Facility Counts ---*/
select source,
	period,
	phyvol,
	facvol
from (
	select 'All' as source,
		year as year,
		month(event_date) as month,
		month(event_date) || '-' || year as period,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol
	from sandbox.<TableName>_D2
	group by year,
		month,
		month(event_date) || '-' || year
	
	union all
	
	select source,
		year as year,
		month(event_date) as month,
		month(event_date) || '-' || year as period,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol
	from sandbox.<TableName>_V2
	group by year,
		month,
		month(event_date) || '-' || year,
		source
	)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	year,
	month,
	period
;

	
/*-- Quarterly New Physician Count ---*/
select source,
	period,
	phy_count
from (
	select 'All' as source,
		year(first_date) as year,
		'Q' || quarter(first_date) || '-' || year(first_date) as period,
		count(physician_npi) as phy_count
	from (
		select physician_npi,
			min(event_date) as first_date
		from sandbox.<TableName>_D1
		group by physician_npi
		) as aa
	group by year,
		'Q' || quarter(first_date) || '-' || year(first_date)
	
	union all
	
	select source as source,
		year(first_date) as year,
		'Q' || quarter(first_date) || '-' || year(first_date) as period,
		count(physician_npi) as phy_count
	from (
		select source,
			physician_npi,
			min(event_date) as first_date
		from sandbox.<TableName>_V1
		group by physician_npi,
			source
		) as aa
	group by year,
		'Q' || quarter(first_date) || '-' || year(first_date),
		source
	)
where right(period, 4) >= <Startyear>
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	year,
	period
;	

	
/*-- Monthly New Physician Count ---*/
select source,
	period,
	phy_count
from (
	select 'All' as source,
		year(first_date) as year,
		month(first_date) as month,
		month(first_date) || '-' || year(first_date) as period,
		count(physician_npi) as phy_count
	from (
		select physician_npi,
			min(event_date) as first_date
		from sandbox.<TableName>_D1
		group by physician_npi
		) as aa
	group by year,
		month,
		month(first_date) || '-' || year(first_date)
	
	union all
	
	select source as source,
		year(first_date) as year,
		month(first_date) as month,
		month(first_date) || '-' || year(first_date) as period,
		count(physician_npi) as phy_count
	from (
		select source,
			physician_npi,
			min(event_date) as first_date
		from sandbox.<TableName>_V1
		group by physician_npi,
			source
		) as aa
	group by year,
		month,
		month(first_date) || '-' || year(first_date),
		source
	)
where right(period, 4) >= <StartYear>
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	year,
	month
;	

	
/*--- Payer Type Patient/Claim counts --*/
select source,
	ins_type,
	patvol,
	claimvol
from (
	select 'All' as source,
		ins_type,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_D2
	group by ins_type
	
	union all
	
	select source,
		ins_type as ins_type,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_V2
	group by source,
		ins_type
	)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	patvol desc
;

		
/*--- Payer Type Patient/Claims count by quarter--*/
select source,
	quarter1,
	ins_type,
	patvol,
	claimvol
from (
	select 'All' as source,
		year,
		'Q' || quarter || '-' || year as quarter1,
		ins_type,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_D2
	group by year,
		'Q' || quarter || '-' || year,
		ins_type
	
	union all
	
	select source,
		year,
		'Q' || quarter || '-' || year as quarter1,
		ins_type,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_V2
	group by year,
		source,
		'Q' || quarter || '-' || year,
		ins_type
	)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	year,
	quarter1,
	patvol desc
;	

	
/*--- Payer Type Patient/Claim count by Month--*/
select source,
	quarter1,
	ins_type,
	patvol,
	claimvol
from (
	select 'All' as source,
		year,
		month(event_date) as month,
		month(event_date) || '-' || year as quarter1,
		ins_type,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_D2
	group by year,
		month,
		month(event_date) || '-' || year,
		ins_type
	
	union all
	
	select source,
		year,
		month(event_date) as month,
		month(event_date) || '-' || year as quarter1,
		ins_type,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_V2
	group by year,
		month,
		source,
		month(event_date) || '-' || year,
		ins_type
	)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	year,
	month,
	quarter1,
	patvol desc
;	

	
/*--- Point of Care type counts ---*/
select *
from (
	select 'All' as source,
		pointofcaretype,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_D2
	--where pointofcaretype is not null
	group by pointofcaretype
	
	union all
	
	select source,
		pointofcaretype,
		count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol
	from sandbox.<TableName>_V2
	--where pointofcaretype is not null
	group by source,
		pointofcaretype
	) 
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end,
	patvol desc
;	

		
/*-- Patient/Claim counts by Physician NPI ---*/
select physician_npi,
	count(distinct encrypted_key_1||encrypted_key_2) as patvol,
	count(distinct claim_no) as claimvol
from sandbox.<TableName>_D2
group by physician_npi
order by patvol desc
;


/*-- Patient/Claim counts by Facility NPI ---*/
select facility_npi,
	count(distinct encrypted_key_1||encrypted_key_2) as patvol,
	count(distinct claim_no) as 	
from sandbox.<TableName>_D2
group by facility_npi
order by patvol desc
;


/*--- Projections for Q3 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_D2
	where year = '2016'
		and quarter = 3
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_D2
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_D2
	where year = '2016'
		and quarter = 3
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_D2
	where year = '2017'
		and quarter = 3
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_D2
			)
	)
order by sord
;


/*--- Projections for Q4 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_D2
	where year = '2016'
		and quarter = 4
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_D2
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_D2
	where year = '2016'
		and quarter = 4
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_D2
	where year = '2017'
		and quarter = 4
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_D2
			)
	)
order by sord
;


/*--- Projections for Albatross Q3 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'Albatross'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'Albatross'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'Albatross'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 3
		and source = 'Albatross'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'Albatross'
			)
	)
order by sord
;


/*--- Projections for Albatross Q4 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'Albatross'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'Albatross'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'Albatross'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 4
		and source = 'Albatross'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'Albatross'
			)
	)
order by sord
;


/*--- Projections for Condor Q3 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'Condor'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'Condor'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'Condor'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 3
		and source = 'Condor'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'Condor'
			)
	)
order by sord
;


/*--- Projections for Condor Q4 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'Condor'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'Condor'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'Condor'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 4
		and source = 'Condor'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'Condor'
			)
	)
order by sord
;


/*--- Projections for CondorRx Q3 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'CondorRx'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'CondorRx'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'CondorRx'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 3
		and source = 'CondorRx'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'CondorRx'
			)
	)
order by sord
;


/*--- Projections for CondorRx Q4 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'CondorRx'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'CondorRx'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'CondorRx'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 4
		and source = 'CondorRx'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'CondorRx'
			)
	)
order by sord
;
/*--- Projections for Osprey Q3 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'Osprey'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'Osprey'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'Osprey'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 3
		and source = 'Osprey'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'Osprey'
			)
	)
order by sord
;

/*--- Projections for Osprey Q4 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'Osprey'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'Osprey'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'Osprey'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 4
		and source = 'Osprey'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'Osprey'
			)
	)
order by sord
;

/*--- Projections for Osprey Rx Q3 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'OspreyRx'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'OspreyRx'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'OspreyRx'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 3
		and source = 'OspreyRx'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'OspreyRx'
			)
	)
order by sord
;

/*--- Projections for Osprey Q4 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'OspreyRx'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'OspreyRx'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'OspreyRx'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 4
		and source = 'OspreyRx'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'OspreyRx'
			)
	)
order by sord
;


/*--- Projections for Vulture Q3 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'Vulture'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'Vulture'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 3
		and source = 'Vulture'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 3
		and source = 'Vulture'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'Vulture'
			)
	)
order by sord
;


/*--- Projections for Vulture Q4 ---*/
select patvol,
	claimvol,
	phyvol,
	facvol,
	medicare_patvol,
	comm_patvol,
	other_patvol,
	medicaid_patvol,
	medicare_claimvol,
	comm_claimvol,
	other_claimvol,
	medicaid_claimvol
from (
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		1 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'Vulture'
		and process_date <= (
			select dateadd(year, - 1, max(process_date))
			from sandbox.<TableName>_V2
			where source = 'Vulture'
			)
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		2 as sord
	from sandbox.<TableName>_V2
	where year = '2016'
		and quarter = 4
		and source = 'Vulture'
	
	union
	
	select count(distinct encrypted_key_1||encrypted_key_2) as patvol,
		count(distinct claim_no) as claimvol,
		count(distinct physician_npi) as phyvol,
		count(distinct facility_npi) as facvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then encrypted_key_1||encrypted_key_2
				end) as medicare_patvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then encrypted_key_1||encrypted_key_2
				end) as comm_patvol,
		count(distinct case 
				when ins_type = 'Other'
					then encrypted_key_1||encrypted_key_2
				end) as other_patvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then encrypted_key_1||encrypted_key_2
				end) as medicaid_patvol,
		count(distinct case 
				when ins_type = 'Medicare'
					then claim_no
				end) as medicare_claimvol,
		count(distinct case 
				when ins_type = 'Commercial'
					then claim_no
				end) as comm_claimvol,
		count(distinct case 
				when ins_type = 'Other'
					then claim_no
				end) as other_claimvol,
		count(distinct case 
				when ins_type = 'Medicaid'
					then claim_no
				end) as medicaid_claimvol,
		3 as sord
	from sandbox.<TableName>_V2
	where year = '2017'
		and quarter = 4
		and source = 'Vulture'
		and process_date <= (
			select max(process_date)
			from sandbox.<TableName>_V2
			where source = 'Vulture'
			)
	)
order by sord
;


/*--- Lag between service date and process date ---*/
with b_cte as 
(with a_cte as
(
select * from
(select 'All' as source, 
	cast((datediff(day, event_date, process_date)) as numeric(10, 0)) as lag,
	count(distinct claim_no) as claimvol
from (
	select claim_no,
		process_date,
		max(event_date) as event_date
	from sandbox.<TableName>_D2 t1
	group by claim_no,
		process_date
	) aa
where lag >= 0
group by cast((datediff(day, event_date, process_date)) as numeric(10, 0))
union all
select source, 
	cast((datediff(day, event_date, process_date)) as numeric(10, 0)) as lag,
	count(distinct claim_no) as claimvol
from (
	select source, claim_no,
		process_date,
		max(event_date) as event_date
	from sandbox.<TableName>_V2 t1
	group by source, claim_no,
		process_date
	) aa
where lag >= 0
group by source, cast((datediff(day, event_date, process_date)) as numeric(10, 0))
)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end, lag
;


/*--- Lag Summary at 15, 30, 60, 90 days interval ---*/
/*------Changes required
1. Added CTE
--------*/
with b_cte as 
(with a_cte as
(select * from
(select 'All' as source, 
	cast((datediff(day, event_date, process_date)) as numeric(10, 0)) as lag,
	count(distinct claim_no) as claimvol
from (
	select claim_no,
		process_date,
		max(event_date) as event_date
	from sandbox.<TableName>_D2 t1
	group by claim_no,
		process_date
	) aa
where lag >= 0
group by cast((datediff(day, event_date, process_date)) as numeric(10, 0))
union all
select source, 
	cast((datediff(day, event_date, process_date)) as numeric(10, 0)) as lag,
	count(distinct claim_no) as claimvol
from (
	select source, claim_no,
		process_date,
		max(event_date) as event_date
	from sandbox.<TableName>_V2 t1
	group by source, claim_no,
		process_date
	) aa
where lag >= 0
group by source, cast((datediff(day, event_date, process_date)) as numeric(10, 0))
)
order by case source
		when 'All'
			then 1
		when 'Albatross'
			then 2
		when 'Condor'
			then 3
		when 'CondorRx'
			then 4	
		when 'Osprey'
			then 5
		when 'OspreyRx'
			then 6
		when 'Vulture'
			then 7
		end, lag
)        

select source, '15' as days, sum(claimvol) as claimvol
from
a_cte
where lag <= 15
group by source
union all
select source, '30' as days, sum(claimvol)
from
a_cte
where lag <= 30
group by source
union all
select source, '60' as days, sum(claimvol)
from
a_cte
where lag <= 60
group by source
union all
select source, '90' as days, sum(claimvol)
from
a_cte
where lag <= 90
group by source
union all
select source, 'Total' as days, sum(claimvol)
from
a_cte
group by source
)

select
IFNULL(sum(distinct case when source = 'All' then claimvol end)/
(select claimvol from b_cte where source = 'All' and days = 'Total'), 0) as c1,
IFNULL(sum(distinct case when source = 'Albatross' then claimvol end)/
(select claimvol from b_cte where source = 'Albatross' and days = 'Total'), 0) as c2,
IFNULL(sum(distinct case when source = 'Condor' then claimvol end)/
(select claimvol from b_cte where source = 'Condor' and days = 'Total'), 0) as c3,
IFNULL(sum(distinct case when source = 'CondorRx' then claimvol end)/
(select claimvol from b_cte where source = 'CondorRx' and days = 'Total'), 0) as c4,
IFNULL(sum(distinct case when source = 'Osprey' then claimvol end)/
(select claimvol from b_cte where source = 'Osprey' and days = 'Total'), 0) as c5,
IFNULL(sum(distinct case when source = 'OspreyRx' then claimvol end)/
(select claimvol from b_cte where source = 'OspreyRx' and days = 'Total'), 0) as c6,
IFNULL(sum(distinct case when source = 'Vulture' then claimvol end)/
(select claimvol from b_cte where source = 'Vulture' and days = 'Total'), 0) as c7
from b_cte
where days <> 'Total'
group by days
order by days

