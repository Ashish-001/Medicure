WITH RECURSIVE rel_tree AS (
   SELECT 
       node_1_id,
       node_1_label,
       node_2_id,
       node_2_label,
   
    1 AS level,
       array[node_2_id, node_1_id] AS path_info_id_arr,
   
    array[node_2_label || '', node_1_label || '']::VARCHAR[] AS path_info_label_arr,
   
    (node_2_id || '_' || node_2_label || '->' || node_1_id || '_' || node_1_label) AS path_info
  
 FROM affiliations
   WHERE node_2_id = 8870 AND node_2_label = 'healthsystem' and node_1_label!='physician'
 
  UNION ALL
   SELECT
       c.node_1_id,
       c.node_1_label,
       c.node_2_id,
       c.node_2_label,
     
  p.level + 1,
       p.path_info_id_arr || c.node_1_id,
      (p.path_info_label_arr || c.node_1_label)::VARCHAR[],
  
    p.path_info || ' -> ' || (c.node_1_id || '_' || c.node_1_label)
   FROM affiliations c
    
 JOIN rel_tree p ON c.node_2_id = p.node_1_id AND c.node_2_label = p.node_1_label
   
  WHERE c.node_1_label!='physician'
)

SELECT
    level,
    path_info,
    path_info_id_arr[1],
 
   path_info_label_arr[1],
    node_1_id,
    node_1_label
FROM rel_tree;

--psql -h hdb.db.compile.com 
-d headbase_export -U drg -A -F , -X -t -f x.sql -o x.csv

