-----------------------Code for Pulling patients with more than 2 valid PHQ-9 values-----------------------

/* Pulling PHQ - 9 records from EHR that have valid values */

Create table JT_Janssen_PHQ9_EHR as
WITH T1 AS
  (SELECT          Encrypted_key_1,
                   Encrypted_key_2,
                   ENCOUNTERID,
                   recordedDTTM,
                   performedDTTM
   FROM rwd_db.rwd.albatross_EHR_results
   WHERE (UPPER(TEST_NAME) LIKE '%PHQ-9%'
          OR UPPER(TEST_NAME) LIKE '%PHQ9%'
          OR UPPER(PANEL) LIKE '%PHQ-9%'
          OR UPPER(PANEL) LIKE '%PHQ9%')
     AND TRY_TO_NUMBER(VALUE_X) >= 0
     AND ERRORFLAG != 'Y'
     AND Resultstatus not in ('Canceled','Cancelled','Entered in Error',
                              'Rejected','Unacknowledged')
     AND encrypted_key_1  NOT like 'XXX -%'
     AND encrypted_key_1  IS NOT NULL
     AND encrypted_key_1  <> ''
     AND encrypted_key_1  <> 'NULL')
SELECT Encrypted_key_1,Encrypted_key_2,
       COUNT(DISTINCT COALESCE(recordedDTTM, performedDTTM)) AS TEST_COUNT1,
       COUNT(DISTINCT ENCOUNTERID) AS TEST_COUNT2
FROM T1
GROUP BY 1,2
--HAVING TEST_COUNT1 > 1
--OR TEST_COUNT2 > 1


Create or replace table JT_Janssen_PHQ9_PELICAN as
Select Encrypted_key_1,Encrypted_key_2, COUNT(DISTINCT COALESCE(REPORT_DATE,OBSERVED_AT)) AS TEST_COUNT1,
                   COUNT(DISTINCT TRANSCRIPT_ID) AS TEST_COUNT2
From RWD_DB.RWD.PELICAN_LABORDER as a join RWD_DB.RWD.PELICAN_DEID as b

on a.PATIENT_ID = b.PATIENT_ID

Where a.LOINC_NUM in ('44261-6','54635-8','54676-2','54674-7','54646-5','54640-8','54673-9',
                    '54654-9','54637-4','54667-1','54669-7','44262-4','44257-4',
                    '54662-2','54645-7','54636-6','54675-4','54665-5','54649-9',
                    '44261-6','54647-3','54666-3','54661-4','54652-3','58152-0',
                    '54639-0','54651-5','54659-8','54648-1','54677-0','54670-5',
                    '58153-8','54641-6','54644-0','54671-3','54643-2','54664-8',
                    '54653-1','54650-7','54660-6','54657-2','44249-1','54672-1',
                    '54668-9','54638-2','54658-0','54663-0','54642-4','73832-8',
                    '57242-0','44249-1','73831-0','55758-7')
      AND a.OBS_QUAN >= 0
      AND a.OBS_QUAN <= 27
      AND encrypted_key_1  NOT like 'XXX -%'
      AND encrypted_key_1  IS NOT NULL
      AND encrypted_key_1  <> ''
      AND encrypted_key_1  <> 'NULL'

Group by 1,2      
   
      
Create or replace table JT_Janssen_PHQ9_Comb as

Select Encrypted_key_1,Encrypted_key_2,TEST_COUNT1,TEST_COUNT2
From JT_Janssen_PHQ9_EHR


Union


Select Encrypted_key_1,Encrypted_key_2,TEST_COUNT1,TEST_COUNT2
From JT_Janssen_PHQ9_PELICAN


;

/* Keeping the patients from above that have a presence in Medical Claims*/

Create table JT_Janssen_PHQ9_Comb_linked as

Select a.Encrypted_key_1,a.Encrypted_key_2

From JT_Janssen_PHQ9_Comb as a join RWD_DB.RWD.RAVEN_CLAIMS_SUBMITS_HEADER as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

Where TEST_COUNT1 > 1
   OR TEST_COUNT2 > 1
   
Union

Select a.Encrypted_key_1,a.Encrypted_key_2

From JT_Janssen_PHQ9_Comb as a join RWD_DB.RWD.RAVEN_PHARMACY as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

Where TEST_COUNT1 > 1
   OR TEST_COUNT2 > 1

;   


/* Keeping the patients from the Claims linked PHQ-9 records that have a DX for MDD in Medical Claims*/

  
Create table JT_Janssen_PHQ9_Comb_linked_MDD_a as

Select a.Encrypted_key_1,a.Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked as a join RWD_DB.RWD.RAVEN_CLAIMS_SUBMITS_DIAGNOSIS as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

Where DIAGNOSIS in ('29620','29621','29622','29623','29624','29625','29626','29630','29631','29632','29633','29634','29635','29636','F320','F321','F322','F323','F324','F325','F328',
 'F3281','F3289','F329','F330','F331','F332','F333','F334','F338','F339','F3340','F3341','F3342','296.20','296.21','296.22','296.23','296.24','296.25','296.26',
 '296.30','296.31','296.32','296.33','296.34','296.35','296.36','F32.0','F32.1','F32.2','F32.3','F32.4','F32.5','F32.8','F32.81','F32.89','F32.9','F33.0','F33.1',
 'F33.2','F33.3','F33.4','F33.8','F33.9','F33.40','F33.41','F33.42','296.2','296.3','2962','2963','F32','F33')


;

/* Keeping the patients from the Claims linked PHQ-9 records that have a DX for MDD in EHR*/

Create table JT_Janssen_PHQ9_Comb_linked_MDD_b as

Select a.Encrypted_key_1,a.Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked as a join rwd_db.rwd.albatross_EHR_Problems as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

Where ICD9 in ('29620','29621','29622','29623','29624','29625','29626','29630','29631','29632','29633','29634','29635','29636','F320','F321','F322','F323','F324','F325','F328',
 'F3281','F3289','F329','F330','F331','F332','F333','F334','F338','F339','F3340','F3341','F3342','296.20','296.21','296.22','296.23','296.24','296.25','296.26',
 '296.30','296.31','296.32','296.33','296.34','296.35','296.36','F32.0','F32.1','F32.2','F32.3','F32.4','F32.5','F32.8','F32.81','F32.89','F32.9','F33.0','F33.1',
 'F33.2','F33.3','F33.4','F33.8','F33.9','F33.40','F33.41','F33.42','296.2','296.3','2962','2963','F32','F33')
 
 Or ICD10 in ('29620','29621','29622','29623','29624','29625','29626','29630','29631','29632','29633','29634','29635','29636','F320','F321','F322','F323','F324','F325','F328',
 'F3281','F3289','F329','F330','F331','F332','F333','F334','F338','F339','F3340','F3341','F3342','296.20','296.21','296.22','296.23','296.24','296.25','296.26',
 '296.30','296.31','296.32','296.33','296.34','296.35','296.36','F32.0','F32.1','F32.2','F32.3','F32.4','F32.5','F32.8','F32.81','F32.89','F32.9','F33.0','F33.1',
 'F33.2','F33.3','F33.4','F33.8','F33.9','F33.40','F33.41','F33.42','296.2','296.3','2962','2963','F32','F33')

 
;

/* Keeping the patients from the Claims linked PHQ-9 records that have a DX for MDD in Pelican*/

 
Create table JT_Janssen_PHQ9_Comb_linked_MDD_c as

Select a.Encrypted_key_1,a.Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked as a Join RWD_DB.RWD.PELICAN_DEID as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

                                      Join RWD_DB.RWD.PELICAN_Diagnosis as c
                                      
                                      On b.Patient_id = c.Patient_id
                                      
                                      Left Join RWD_DB.RWD.PELICAN_Diagnosis_icd10 as d
                                      
                                      On c.Diagnosis_id = d.Diagnosis_id

                                      Left Join RWD_DB.RWD.PELICAN_Diagnosis_icd9 as e
                                      
                                      On c.Diagnosis_id = e.Diagnosis_id

Where e.ICD9 in ('29620','29621','29622','29623','29624','29625','29626','29630','29631','29632','29633','29634','29635','29636','F320','F321','F322','F323','F324','F325','F328',
 'F3281','F3289','F329','F330','F331','F332','F333','F334','F338','F339','F3340','F3341','F3342','296.20','296.21','296.22','296.23','296.24','296.25','296.26',
 '296.30','296.31','296.32','296.33','296.34','296.35','296.36','F32.0','F32.1','F32.2','F32.3','F32.4','F32.5','F32.8','F32.81','F32.89','F32.9','F33.0','F33.1',
 'F33.2','F33.3','F33.4','F33.8','F33.9','F33.40','F33.41','F33.42','296.2','296.3','2962','2963','F32','F33')
 
 Or d.ICD10 in ('29620','29621','29622','29623','29624','29625','29626','29630','29631','29632','29633','29634','29635','29636','F320','F321','F322','F323','F324','F325','F328',
 'F3281','F3289','F329','F330','F331','F332','F333','F334','F338','F339','F3340','F3341','F3342','296.20','296.21','296.22','296.23','296.24','296.25','296.26',
 '296.30','296.31','296.32','296.33','296.34','296.35','296.36','F32.0','F32.1','F32.2','F32.3','F32.4','F32.5','F32.8','F32.81','F32.89','F32.9','F33.0','F33.1',
 'F33.2','F33.3','F33.4','F33.8','F33.9','F33.40','F33.41','F33.42','296.2','296.3','2962','2963','F32','F33')


;


Create table JT_Janssen_PHQ9_Comb_linked_MDD as 

Select Encrypted_key_1, Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked_MDD_a

Union

Select Encrypted_key_1, Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked_MDD_b

Union

Select Encrypted_key_1, Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked_MDD_c

;


/* Retaining Patients who an administration of atleast 3 Anit-Depressants  */


Create table JT_Janssen_PHQ9_Comb_linked_MDD_Meds_a as

Select a.Encrypted_key_1, a.Encrypted_key_2, Count(distinct DRUG_NAME) as Meds

From JT_Janssen_PHQ9_Comb_linked_MDD as a Join RWD_DB.RWD.RAVEN_CLAIMS_SUBMITS_PROCEDURE as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

                                          Join project_analytics.jnj_mdd.SB_MDD_NDCLIST_10102018 as c
                                          
                                          On Trim(b.NDC) = Trim(c.NDC)
                                          
Group by 1,2

Having Meds >= 3


;


Create table JT_Janssen_PHQ9_Comb_linked_MDD_Meds_b as

Select a.Encrypted_key_1, a.Encrypted_key_2, Count(distinct DRUG_NAME) as Meds

From JT_Janssen_PHQ9_Comb_linked_MDD as a Join rwd_db.rwd.albatross_EHR_medications as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

                                          Join project_analytics.jnj_mdd.SB_MDD_NDCLIST_10102018 as c
                                          
                                          On Trim(b.NDC) = Trim(c.NDC)
                                          
Group by 1,2

Having Meds >= 3


;

Create table JT_Janssen_PHQ9_Comb_linked_MDD_Meds_c as

Select a.Encrypted_key_1, a.Encrypted_key_2, Count(distinct DRUG_NAME) as Meds

From JT_Janssen_PHQ9_Comb_linked_MDD as a Join RWD_DB.RWD.PELICAN_DEID as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

                                          Join RWD_DB.RWD.PELICAN_PRESCRIPTION as c
                                          
                                          On b.PATIENT_ID = c.PATIENT_ID
                                          
                                          
                                          Join project_analytics.jnj_mdd.SB_MDD_NDCLIST_10102018 as d
                                          
                                          On Trim(c.MEDICATION_ID) = Trim(d.NDC)
                                          
Group by 1,2

Having Meds >= 3


Create table JT_Janssen_PHQ9_Comb_linked_MDD_Meds_d as

Select a.Encrypted_key_1, a.Encrypted_key_2, Count(distinct DRUG_NAME) as Meds

From JT_Janssen_PHQ9_Comb_linked_MDD as a Join  RWD_DB.RWD.RAVEN_PHARMACY as b

On  a.Encrypted_key_1 = b.Encrypted_key_1
AND a.Encrypted_key_2 = b.Encrypted_key_2

                                          Join project_analytics.jnj_mdd.SB_MDD_NDCLIST_10102018 as c
                                          
                                          On Trim(b.PRODUCT_OR_SERVICE_ID) = Trim(c.NDC)
                                          
Group by 1,2

Having Meds >= 3


;

Create table JT_Janssen_PHQ9_Comb_linked_MDD_Meds as

Select Encrypted_key_1, Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked_MDD_Meds_a

Union

Select Encrypted_key_1, Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked_MDD_Meds_b

Union

Select Encrypted_key_1, Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked_MDD_Meds_c

Union

Select Encrypted_key_1, Encrypted_key_2

From JT_Janssen_PHQ9_Comb_linked_MDD_Meds_d













