

////////////////////Clients table for checkin Client ID///////////////////////

create table presales.AC_Olym_EHR_Client as
Select distinct GENCLIENTID from RWD_DB.RWD.ALBATROSS_EHR_CLIENTS


create table presales.AC_Olym_EHR_Prob as
SELECT 
    
      b.ENCRYPTED_KEY_1 as PATIENT_SUFFIX
	  ,b.encrypted_key_2
      ,(case when b.Encrypted_key_2 is null then b.Encrypted_key_1 else b.Encrypted_key_1||b.Encrypted_key_2 end) as Patient_ID
	 , CAST(b.ENCOUNTERID as STRING) as CLAIM_NUMBER
	
     , CAST(b.RECORDEDDTTM as DATE) as STATEMENT_FROM_NEW
	 , a.GENCLIENTID
FROM presales.AC_Olym_EHR_Client a

left join RWD_DB.RWD.ALBATROSS_EHR_PROBLEMS b on a.GENCLIENTID=b.GENCLIENTID

where 
   
  trim(b.ENCRYPTED_KEY_1) is not null
  AND trim(b.ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(b.ENCRYPTED_KEY_1) <>''
  AND trim(upper(b.ENCRYPTED_KEY_1)) <> 'NULL'
  and trim (lower(b.status)) not in ('entered in error','erroneous entry')
  
  ///Facility counts////
  
  Select Year(STATEMENT_FROM_NEW) as Year, count(distinct GENCLIENTID) from presales.AC_Olym_EHR_Prob
  group by 1
  order by 1
  
  ///Counting patients///
  Select Year(STATEMENT_FROM_NEW) as Year, count(distinct Patient_ID), count(distinct GENCLIENTID) as Gen_Count from presales.AC_Olym_EHR_Prob
  group by 1
  having Gen_Count >= '2'
  order by 1
  
  
  ///////////////////////////////Physicians///////////////////////////////////
  
  create table presales.AC_Olym_EHR_Phys as
SELECT 
    
      ENCRYPTED_KEY_1 as PATIENT_SUFFIX
	  ,encrypted_key_2
      ,(case when Encrypted_key_2 is null then Encrypted_key_1 else Encrypted_key_1||Encrypted_key_2 end) as Patient_ID
	   ,NPI_TITLE
	   ,SPECIALTY
	 , GENPROVIDE;RID
FROM RWD_DB.RWD.ALBATROSS_EHR_PROVIDERS

where 
   
  trim(ENCRYPTED_KEY_1) is not null
  AND trim(ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(ENCRYPTED_KEY_1) <>''
  AND trim(upper(ENCRYPTED_KEY_1)) <> 'NULL'
  
  
  ////Adding case for Physcian type///
  
   create or replace table presales.AC_Olym_EHR_Phys_1 as
  Select *,
  case when lower(NPI_TITLE) LIKE '%doctor%' or lower(NPI_TITLE) like '%osteopathic%' OR
             lower(npi_title) LIKE '%surgeon%' THEN 'Doctor' 
  when lower(NPI_TITLE) LIKE '%clinical nurse specialist%' or lower(NPI_TITLE) like '%physician assistant Certified%' OR
             lower(npi_title) LIKE '%physician assistant%' or lower(npi_title) LIKE '%licensed acupuncturist%' THEN 'Nurse' 
  when lower(NPI_TITLE) LIKE '%nurse practitioner%' or lower(NPI_TITLE) like '%advanced practice registered nurse%' OR
             lower(npi_title) LIKE '%licensed practical nurse%' or lower(npi_title) LIKE '%advanced practice nurse%' or
  lower(npi_title) LIKE '%certified nurse midwife%' or lower(npi_title) LIKE '%certified registered nurse anesthetist%'           
             THEN 'Nurse Practitioner'
  when lower(npi_title) is null  then 'Others'  end as Phy_type        
             
             
   from    presales.AC_Olym_EHR_Phys       
   
   
   /////////////////////////Adding specialties////////////////////////
   
   create or replace table presales.AC_Olym_EHR_Phys_Spec as
   Select *,
   case when lower(SPECIALTY) like '%medicine%' then 'Medicine'
   when lower(SPECIALTY) like '%anaesthes%' then 'Anaesthesia'
   when lower(SPECIALTY) like '%dermatolog%' then 'Dermatology'
   when lower(SPECIALTY) like '%emergency%' then 'Emergency'
   when lower(SPECIALTY) like '%general practice%' then 'General practice'
   when lower(SPECIALTY) like '%intensive care%' then 'Intensive care medicine'
   when lower(SPECIALTY) like '%obstetrics%' then 'Obstetrics and gynaecology'
   when lower(SPECIALTY) like '%ophthalmolog%' then 'Ophthalmology'
   when lower(SPECIALTY) like '%paediatric%' then 'Paediatrics and child health'
   when lower(SPECIALTY) like '%pathology%' then 'Pathology'
   when lower(SPECIALTY) like '%psychiatr%' then 'Psychiatry'
   when lower(SPECIALTY) like '%radiolog%' then 'Radiology'
   when lower(SPECIALTY) like '%surger%' then 'Surgery'
   when lower(SPECIALTY) like '%rheumatolog%' then 'Rheumatology'
   when lower(SPECIALTY) like '%oncolog%' then 'Oncology'
   when lower(SPECIALTY) like '%cardiolog%' then 'Cardiology'
   when lower(SPECIALTY) like '%neurolog%' then 'Neurology'
   when lower(SPECIALTY) like '%otorhinolaryngolog%' then 'Otorhinolaryngology'
   when lower(SPECIALTY) like '%dentist%' then 'Dentistry'
   when lower(SPECIALTY) like '%pulmonolog%' then 'Pulmonology'
   when lower(SPECIALTY) like '%gastroenterolog%' then 'Gastroenterology'
   when lower(SPECIALTY) like '%nephrolog%' then 'Nephrology'
   when lower(SPECIALTY) like '%immunolog%' then 'Immunology'
   when lower(SPECIALTY) like '%orthopaedic%' then 'Orthopaedics'
   else 'Others' end as Spec
  from presales.AC_Olym_EHR_Phys_1
  
  
  
  /////counts////
  
  Select count(distinct GENPROVIDERID), Phy_type from presales.AC_Olym_EHR_Phys_Spec
  group by Phy_type
  order by Phy_type
  
  ////////////////////////////////////Finding Age, Gender and State///////////////////
  
  
  create or replace table presales.AC_Olym_EHR_Pat as
SELECT 
      ENCRYPTED_KEY_1 as PATIENT_SUFFIX
	  ,encrypted_key_2
      ,(case when Encrypted_key_2 is null then Encrypted_key_1 else Encrypted_key_1||Encrypted_key_2 end) as Patient_ID
      ,DOBYEAR
	  ,GENDER
	  ,STATE_X
      , cast(cast(DOBYEAR as varchar())||'-01-01' as date) as DOB 
FROM RWD_DB.RWD.ALBATROSS_EHR_PATIENTS

/////Finding age////

create or replace table presales.AC_Olym_EHR_Pat_1 as
Select *,
datediff(dd,DOB,current_date())/365.25 as Patient_age
from presales.AC_Olym_EHR_Pat

/******** Adding Age Bucket to all ***********/  

Create or replace table presales.AC_Olym_EHR_Pat_2 as
Select A.*, case when Patient_age < 18 then 'Age <18'
                when Patient_age >= 18 and Patient_age < 28 then 'Age 18-27'
                when Patient_age >= 28 and Patient_age < 38 then 'Age 28-37'
                when Patient_age >= 38 and Patient_age < 48 then 'Age 38-47'
                when Patient_age >= 48 and Patient_age < 58 then 'Age 48-57'
                when Patient_age >= 58 and Patient_age < 68 then 'Age 58-67'
                when Patient_age >= 68 and Patient_age < 77 then 'Age 68-77'
                when Patient_age >=77 then 'Age >77' end as Age_Bucket
from presales.AC_Olym_EHR_Pat_1


////counts////
Select Age_Bucket, count(distinct Patient_ID) from presales.AC_Olym_EHR_Pat_2
group by 1
order by 1

///
Select  GENDER, count(distinct Patient_ID) from presales.AC_Olym_EHR_Pat_2
where Gender is not Null 
group by 1
order by 1

///
Select  STATE_X, count(distinct Patient_ID) from presales.AC_Olym_EHR_Pat_2
where  State_X is not null
group by 1
order by 1

//////////////////////Overlap of patients with Medical claims/////////////////////



Create or replace table presales.AC_Olym_EHR_Med as
Select a.* from presales.AC_Olym_EHR_Pat_2 a
inner join RWD_DB.RWD.RAVEN_CLAIMS_SUBMITS_HEADER b on a.Patient_ID= case when b.Encrypted_key_2 is null then b.Encrypted_key_1 else b.Encrypted_key_1||b.Encrypted_key_2 end
where trim(b.ENCRYPTED_KEY_1) is not null
  AND trim(b.ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(b.ENCRYPTED_KEY_1) <>''
  AND trim(upper(b.ENCRYPTED_KEY_1)) <> 'NULL'
  
  ////Age wise counts////
Select Age_Bucket, count(distinct Patient_ID) from presales.AC_Olym_EHR_Med
group by 1
order by 1

///Gender wise counts/////
Select  GENDER, count(distinct Patient_ID) from presales.AC_Olym_EHR_Med
where Gender is not Null 
group by 1
order by 1

///State wise counts////
Select  STATE_X, count(distinct Patient_ID) from presales.AC_Olym_EHR_Med
where  State_X is not null
group by 1
order by 1
  
  
  ////////////////////////////////Overlap of patients with Pharmacy claims/////////////////////////////////
  

Create or replace table presales.AC_Olym_EHR_Phar as
Select a.* from presales.AC_Olym_EHR_Pat_2 a
inner join RWD_DB.RWD.RAVEN_PHARMACY b on a.Patient_ID= case when b.Encrypted_key_2 is null then b.Encrypted_key_1 else b.Encrypted_key_1||b.Encrypted_key_2 end
where trim(b.ENCRYPTED_KEY_1) is not null
  AND trim(b.ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(b.ENCRYPTED_KEY_1) <>''
  AND trim(upper(b.ENCRYPTED_KEY_1)) <> 'NULL'
  
  
    
  ////Age wise counts////
Select Age_Bucket, count(distinct Patient_ID) from presales.AC_Olym_EHR_Phar
group by 1
order by 1

///Gender wise counts////
Select  GENDER, count(distinct Patient_ID) from presales.AC_Olym_EHR_Phar
where Gender is not Null 
group by 1
order by 1

///State wise counts///
Select  STATE_X, count(distinct Patient_ID) from presales.AC_Olym_EHR_Phar
where  State_X is not null
group by 1
order by 1

////////////////////////overlapping of EHR, Medical and Pharmacy patients//////////////////

Create or replace table presales.AC_Olym_EHR_Phar_Med as
Select a.* from presales.AC_Olym_EHR_Med a
inner join RWD_DB.RWD.RAVEN_PHARMACY b on a.Patient_ID= case when b.Encrypted_key_2 is null then b.Encrypted_key_1 else b.Encrypted_key_1||b.Encrypted_key_2 end
where trim(b.ENCRYPTED_KEY_1) is not null
  AND trim(b.ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(b.ENCRYPTED_KEY_1) <>''
  AND trim(upper(b.ENCRYPTED_KEY_1)) <> 'NULL'
  
  
   ////Age wise counts////
Select Age_Bucket, count(distinct Patient_ID) from presales.AC_Olym_EHR_Phar_Med
group by 1
order by 1

/// Gender wise counts///
Select  GENDER, count(distinct Patient_ID) from presales.AC_Olym_EHR_Phar_Med
where Gender is not Null 
group by 1
order by 1

////State wise counts////
Select  STATE_X, count(distinct Patient_ID) from presales.AC_Olym_EHR_Phar_Med
where  State_X is not null
group by 1
order by 1
  
  
  
  ///////////////////Medications/////////////////////////
  
  create table presales.AC_Olym_EHR_Medical as
SELECT 
    
      ENCRYPTED_KEY_1 as PATIENT_SUFFIX
	  ,encrypted_key_2
      ,(case when Encrypted_key_2 is null then Encrypted_key_1 else Encrypted_key_1||Encrypted_key_2 end) as Patient_ID
	 , CAST(ENCOUNTERID as STRING) as CLAIM_NUMBER
	
     , CAST(RECORDEDDTTM as DATE) as STATEMENT_FROM_NEW
	 , NDC
FROM RWD_DB.RWD.ALBATROSS_EHR_MEDICATIONS 

where 
   
  trim(ENCRYPTED_KEY_1) is not null
  AND trim(ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(ENCRYPTED_KEY_1) <>''
  AND trim(upper(ENCRYPTED_KEY_1)) <> 'NULL'
  and trim (lower(status)) in ('','active','administered','auto complete','complete','completed','continued','discontinued','filled rx'
  ,'hold for','in progress','ordered','other','pending','resulted')
  and trim(lower(PrescribeAction)) not in ('cancel')

  
  ///Patient counts for NDC ////
 
   Select  count(distinct Patient_ID) as Pat_count, Year(STATEMENT_FROM_NEW) as Year, left(NDC,9) as NDC_Name from presales.AC_Olym_EHR_Medical
  where NDC_Name is not NULL
  group by Year,NDC_Name
  order by Pat_count desc
  limit 100


//////////////Encounter counts for NDC////////////////
 Select  count(distinct CLAIM_NUMBER) as Encounter, Year(STATEMENT_FROM_NEW) as Year, left(NDC,9) as NDC_Name from presales.AC_Olym_EHR_Medical
  where NDC_Name is not NULL
  group by Year,NDC_Name
  order by Encounter desc
  limit 100
  
  
  
  ///////////////////Results/////////////////////////
  
  create table presales.AC_Olym_EHR_Result as
SELECT 
    
      ENCRYPTED_KEY_1 as PATIENT_SUFFIX
	  ,encrypted_key_2
      ,(case when Encrypted_key_2 is null then Encrypted_key_1 else Encrypted_key_1||Encrypted_key_2 end) as Patient_ID
	 , CAST(ENCOUNTERID as STRING) as Encounter_ID
	
     , CAST(RECORDEDDTTM as DATE) as STATEMENT_FROM_NEW
	 , Test
	 , Panel
	 , LOINC
FROM RWD_DB.RWD.ALBATROSS_EHR_RESULTS 

where 
   
  trim(ENCRYPTED_KEY_1) is not null
  AND trim(ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(ENCRYPTED_KEY_1) <>''
  AND trim(upper(ENCRYPTED_KEY_1)) <> 'NULL'
  and trim (lower(RESULTSTATUS)) not in ('canceled','cancelled','entered in error','rejected')
  
  
  
   ///Patient counts for test ////
 
   Select  count(distinct Patient_ID) as Pat_count, Year(STATEMENT_FROM_NEW) as Year, Test from presales.AC_Olym_EHR_Result
  where Test is not NULL
  group by Year,Test
  order by Pat_count desc
  limit 100


///Patient counts for Panel ////
 Select  count(distinct Patient_ID) as Pat_count, Year(STATEMENT_FROM_NEW) as Year, Upper(Panel) as Panel from presales.AC_Olym_EHR_Result
  where Panel is not NULL
  group by Year,Panel
  order by Pat_count desc
  limit 100

///Patient counts for loinc ////
 Select  count(distinct Patient_ID) as Pat_count, Year(STATEMENT_FROM_NEW) as Year, LOINC from presales.AC_Olym_EHR_Result
  where LOINC is not NULL
  group by Year,LOINC
  order by Pat_count desc
  limit 100
  
  
///////By Encounter///////////////


///Encounter counts for Test ////
 
   Select  count(distinct Encounter_ID) as Encounters, Year(STATEMENT_FROM_NEW) as Year, Test from presales.AC_Olym_EHR_Result
  where Test is not NULL
  group by Year,Test
  order by Encounters desc
  limit 100

///Encounter counts for Panel ////
 Select  count(distinct Encounter_ID) as Encounters, Year(STATEMENT_FROM_NEW) as Year, upper(Panel) as Panel from presales.AC_Olym_EHR_Result
  where Panel is not NULL
  group by Year,Panel
  order by Encounters desc
  limit 100

///Encounter counts for loinc ////
 Select  count(distinct Encounter_ID) as Encounters, Year(STATEMENT_FROM_NEW) as Year, LOINC from presales.AC_Olym_EHR_Result
  where LOINC is not NULL
  group by Year,LOINC
  order by Encounters desc
  limit 100
  
  
  
   ///////////////////Problems/////////////////////////
  
  create table presales.AC_Olym_EHR_Problems as
SELECT 
    
      ENCRYPTED_KEY_1 as PATIENT_SUFFIX
	  ,encrypted_key_2
      ,(case when Encrypted_key_2 is null then Encrypted_key_1 else Encrypted_key_1||Encrypted_key_2 end) as Patient_ID
	 , CAST(ENCOUNTERID as STRING) as Encounter_ID
	
     , CAST(RECORDEDDTTM as DATE) as STATEMENT_FROM_NEW
	 , ICD9
	 , ICD10
	 , SNOMED
FROM RWD_DB.RWD.ALBATROSS_EHR_PROBLEMS 

where 
   
  trim(ENCRYPTED_KEY_1) is not null
  AND trim(ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(ENCRYPTED_KEY_1) <>''
  AND trim(upper(ENCRYPTED_KEY_1)) <> 'NULL'
  and trim (lower(STATUS)) not in ('entered in error','erroneous entry')
  
  
  ////////////////////Orders//////////////////////////////////////////////////////
  
  
  
  create table presales.AC_Olym_EHR_Orders as
SELECT 
    
      ENCRYPTED_KEY_1 as PATIENT_SUFFIX
	  ,encrypted_key_2
      ,(case when Encrypted_key_2 is null then Encrypted_key_1 else Encrypted_key_1||Encrypted_key_2 end) as Patient_ID
	 , CAST(ENCOUNTERID as STRING) as Encounter_ID
	
     , CAST(RECORDEDDTTM as DATE) as STATEMENT_FROM_NEW
	 , BILLINGICD9CODE
	 , BILLINGICD10CODE
	 , NULL as SNOMED
FROM RWD_DB.RWD.ALBATROSS_EHR_ORDERS 

where 
   
  trim(ENCRYPTED_KEY_1) is not null
  AND trim(ENCRYPTED_KEY_1) not like 'XXX -%'
  AND trim(ENCRYPTED_KEY_1) <>''
  AND trim(upper(ENCRYPTED_KEY_1)) <> 'NULL'
  and trim (lower(status)) in ('','active','b','complete','discontinued','e','final','g','in progress',
  'n','need information','ordered','pending','preliminary','resulted','reviewed','s','v')
  
  
  /////////////////UNION of EHR tables///////////

drop table if exists presales.AC_Olym_EHR_Orders_Problems;
create table presales.AC_Olym_EHR_Orders_Problems as
Select distinct *  from presales.AC_Olym_EHR_Orders
UNION
Select distinct * from presales.AC_Olym_EHR_Problems



/////Patient Counts for ICD ////////////////
 Select  count(distinct Patient_ID) as Pat_Count, Year(STATEMENT_FROM_NEW) as Year, BILLINGICD10CODE as ICD10 from presales.AC_Olym_EHR_Orders_Problems
  where ICD10 is not NULL
  group by Year,ICD10
  order by Pat_Count desc
  limit 50

//////////Encounter counts for ICD//////////////////
 Select  count(distinct Encounter_ID) as Encounters, Year(STATEMENT_FROM_NEW) as Year, BILLINGICD10CODE as ICD10 from presales.AC_Olym_EHR_Orders_Problems
  where ICD10 is not NULL
  group by Year,ICD10
  order by Encounters desc
  limit 100