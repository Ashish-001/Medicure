create table sandbox.pel_vitals as 
--height
select 
    patient_id
    ,transcript_id as encounter_id
    ,cast(concat(transcript_id, dos) as varchar) as vital_id
    ,NULL as version_id
    ,'height' as vital_name
    ,NULL as STATUS
    ,cast(height as varchar) as VALUE_X
    ,'in' as UNITS
    ,NULL as REFerance_RANGE
    ,NULL as ERROR_FLAG
    ,NULL as CLINICAL_date
    ,dos as PERFORMEd_date
    ,last_modified as RECORDEDDTTM
    ,provider_id
from rwd.pelican_transcript
where height is not NULL
UNION ALL
--weight
select 
    patient_id
    ,transcript_id as encounter_id
    ,cast(concat(transcript_id, dos) as varchar) as vital_id
    ,NULL as version_id
    ,'weight' as vital_name
    ,NULL as STATUS
    ,cast(weight as varchar) as VALUE_X
    ,'lb' as UNITS
    ,NULL as REFerance_RANGE
    ,NULL as ERROR_FLAG
    ,NULL as CLINICAL_date
    ,dos as PERFORMEd_date
    ,last_modified as RECORDEDDTTM
    ,provider_id
from rwd.pelican_transcript
where weight is not NULL
UNION ALL
--calc_bmi
select 
    patient_id
    ,transcript_id as encounter_id
    ,cast(concat(transcript_id, dos) as varchar) as vital_id
    ,NULL as version_id
    ,'calculated_bmi' as vital_name
    ,NULL as STATUS
    ,cast(c_bmi as varchar) as VALUE_X
    ,NULL as UNITS
    ,NULL as REFerance_RANGE
    ,NULL as ERROR_FLAG
    ,NULL as CLINICAL_date
    ,dos as PERFORMEd_date
    ,last_modified as RECORDEDDTTM
    ,provider_id
from rwd.pelican_transcript
where c_bmi is not NULL
UNION ALL
--systolic
select 
    patient_id
    ,transcript_id as encounter_id
    ,cast(concat(transcript_id, dos) as varchar) as vital_id
    ,NULL as version_id
    ,'systolic' as vital_name
    ,NULL as STATUS
    ,cast(systolic_bp as varchar) as VALUE_X
    ,NULL as UNITS
    ,NULL as REFerance_RANGE
    ,NULL as ERROR_FLAG
    ,NULL as CLINICAL_date
    ,dos as PERFORMEd_date
    ,last_modified as RECORDEDDTTM
    ,provider_id
from rwd.pelican_transcript
where systolic_bp is not NULL
UNION ALL
--diastolic
select 
    patient_id
    ,transcript_id as encounter_id
    ,cast(concat(transcript_id, dos) as varchar) as vital_id
    ,NULL as version_id
    ,'diastolic' as vital_name
    ,NULL as STATUS
    ,cast(diastolic_bp as varchar) as VALUE_X
    ,NULL as UNITS
    ,NULL as REFerance_RANGE
    ,NULL as ERROR_FLAG
    ,NULL as CLINICAL_date
    ,dos as PERFORMEd_date
    ,last_modified as RECORDEDDTTM
    ,provider_id
from rwd.pelican_transcript
where diastolic_bp is not NULL 
UNION ALL
--pulse
select 
    patient_id
    ,transcript_id as encounter_id
    ,cast(concat(transcript_id, dos) as varchar) as vital_id
    ,NULL as version_id
    ,'pulse' as vital_name
    ,NULL as STATUS
    ,cast(pulse as varchar) as VALUE_X
    ,NULL as UNITS
    ,NULL as REFerance_RANGE
    ,NULL as ERROR_FLAG
    ,NULL as CLINICAL_date
    ,dos as PERFORMEd_date
    ,last_modified as RECORDEDDTTM
    ,provider_id
from rwd.pelican_transcript
where pulse is not NULL
UNION ALL
--resp rate
select 
    patient_id
    ,transcript_id as encounter_id
    ,cast(concat(transcript_id, dos) as varchar) as vital_id
    ,NULL as version_id
    ,'respiratory rate' as vital_name
    ,NULL as STATUS
    ,cast(resp_rate as varchar) as VALUE_X
    ,NULL as UNITS
    ,NULL as REFerance_RANGE
    ,NULL as ERROR_FLAG
    ,NULL as CLINICAL_date
    ,dos as PERFORMEd_date
    ,last_modified as RECORDEDDTTM
    ,provider_id
from rwd.pelican_transcript
where resp_rate is not NULL;



create table sandbox.alb_pel_vitals as
select 
    cast(genpatientid as varchar) as patient_id
    ,encounterid as encounter_id
    ,cast( vitalid as varchar) as vital_id
    ,cast(versionid as varchar) as version_id
    ,name as vital_name
    ,sTATUS
    ,VALUE_X
    , UNITS
    ,refrange as REFerance_RANGE
    ,errorflag as ERROR_FLAG
    ,cast(clinicaldttm as date) as CLINICAL_date
    ,performeddttm as PERFORMEd_date
    ,cast(recordeddttm as date) as RECORDED_date
    ,cast(genproviderid as varchar) as provider_id
from RWD.ALBATROSS_EHR_vitals
UNION ALL
select * from
sandbox.pel_vitals;

describe table sandbox.pel_vitals
