-------ORDERS from ALB ONLY
create table sandbox.alb_pelican_orders as
select
    GENPATIENTID	as Patient_ID,
    ENCOUNTERID	as Encounter_ID,
    ORDERID	as Order_ID,
    VERSIONID	as Version_ID,
    AUDITDATAFLAG	as Audit_Flag,
    NAME	as Order_Name,
    TYPE	as TYPE,
    STATUS	as STATUS,
    CPT4	as CPT4,
    CPTMOD	as CPTMOD,
    CPTPOS	as CPTPOS,
    BILLINGICD9CODE	as BILLINGICD9CODE,
    BILLINGICD10CODE	as BILLINGICD10CODE,
    HCPCS	as HCPCS,
    SOURCE	as SOURCE,
    SPECIMEN	as SPECIMEN,
    ORDERDTTM	as Order_Date,
    RECORDEDDTTM	as Recorded_Date,
    APPROVINGGENPROVIDERID	as Approving_Provider_ID,
    ORDERINGGENPROVIDERID	as Ordering_Provider_ID,
    PERFORMINGGENPROVIDERID	as Performing_Provider_ID,
    GENPROVIDERID	as Provider_ID,
    PRIMARYKEY	as Primary_Key,
    HIPAA_BILLINGICD9CODE	as HIPAA_BILLINGICD9CODE,
    HIPAA_BILLINGICD10CODE	as HIPAA_BILLINGICD10CODE
from RWD.ALBATROSS_EHR_ORDERS;

----RESULTS NOW
------------ SUBSETTING ALBATROSS EHR RESULTS TABLE -----------------------------

CREATE OR REPLACE TABLE SANDBOX.AG_ALB_RESULTS_01 AS
SELECT DISTINCT
	GENPATIENTID as Patient_ID,
	RESULTID as Result_ID,
	ORDERID as Order_ID,
	panel, 
    TEST as test,
	VALUE_X,
	UNITS,
	ABNORMALFLAG as abnormal_flag,
	RESULTSTATUS as result_status,
	LOINC,
	RESULTDTTM as result_date,
	RECORDEDDTTM as recorded_date,
	GENPROVIDERID as provider_ID,
    encounterID as encounter_ID,
    primarykey as primary_key
FROM RWD.ALBATROSS_EHR_RESULTS;



---------------- CREATING PROTOTYPE EHR RESULTS TABLE FROM PRACTICE FUSION --------------------------

CREATE OR REPLACE TABLE SANDBOX.AG_PF_RESULTS_01 AS
SELECT DISTINCT 
		A.PATIENT_ID AS PATIENT_ID,
		A.LABORDER_ID AS RESULT_ID,
		A.TRANSCRIPT_ID AS ORDER_ID,
        NULL as panel,
		B.NAME AS TEST,
		CASE 
            WHEN A.OBS_QUAN IS NULL 
            THEN A.OBS_QUAL 
            ELSE NULL
        END AS VALUE_X,
        A.OBS_QUAL as RESULT_SNOMED,
		A.UNIT AS UNITS,
		A.ABNORMAL_FLAG AS ABNORMAL_FLAG,
		A.RESULT_STATUS AS RESULT_STATUS,
		A.LOINC_NUM AS LOINC,
		A.REPORT_DATE AS RESULT_date,
		A.CREATED_AT AS RECORDED_date,
		A.PROVIDER_ID AS provider_ID,
        A.transcript_id as encounter_ID,
        NULL as primary_key
FROM RWD.PELICAN_LABORDER AS A
LEFT JOIN (SELECT * FROM RWD.PELICAN_ENCTYPE WHERE CODE_NAME = 'LOINC') AS B ON A.LOINC_NUM = B.CODE;

select * from SANDBOX.AG_PF_RESULTS_01 limit 10;
------------------ CREATING RESULTS TABLE FOR PROTOTYPE ORDER TABLE DERIVED FROM PRACTICE FUSION -------------------------------

CREATE OR REPLACE TABLE SANDBOX.AG_PF_RESULTS_02 AS
SELECT DISTINCT 
                genpatientid, 
                B.RESULT_CODE_ID AS RESULT_ID,
                A.ORDERID,
                NULL as panel,
                A.NAME AS TEST,
				CAST (B.RESULT_VALUE AS VARCHAR) AS VALUE_X,
				NULL AS UNITS,
				NULL AS ABNORMAL_FLAG,
                A.STATUS AS RESULTS_TATUS,
				C.CODE AS LOINC,
                B.CREATED_AT AS RESULT_date,
                A.RECORDEDdttm,
                A.genproviderid,
                A.transcript_id as encounter_ID,
                NULL as primary_key
FROM SANDBOX.AG_PF_ORDERS_01 AS A
JOIN RWD.PELICAN_ENCOUNTER AS B ON A.ENCOUNTERID = B.ENCOUNTER_ID
JOIN (SELECT * FROM RWD.PELICAN_ENCTYPE WHERE CODE_NAME = 'LOINC') AS C ON A.NAME = C.NAME;

describe table SANDBOX.AG_PF_ORDERS_01;

-------------- COMBINING ALL THE TABLES ----------------
CREATE OR REPLACE TABLE sandbox.pelican_alb_results AS
    SELECT DISTINCT 
		Patient_ID,
        Result_ID,
        Order_ID,
        panel,
        Test,
	 	cast(VALUE_X as varchar) as value,
        RESULT_SNOMED,
	  	UNITS,
	  	Abnormal_Flag,
        Result_Status,
        LOINC,
        Result_Date,
        Recorded_Date,
        Provider_ID,
        Encounter_ID,
        primary_key  
  FROM SANDBOX.AG_PF_RESULTS_01  
UNION ALL
/*    SELECT DISTINCT 
		Patient_ID,
        Result_ID,
        Order_ID,
        panel,
        Test,
		CAST(VALUE_X as VARCHAR) as VALUE,
	  	UNITS,
	  	Abnormal_Flag,
        Result_Status,
        LOINC,
        Result_Date,
        Recorded_Date,
        Provider_ID,
        Encounter_ID,
        primary_key  
  FROM SANDBOX.AG_PF_RESULTS_02
UNION ALL*/
    SELECT
 	  	CAST(patient_id as VARCHAR(36)) as patient_id,
        Result_ID,
        Order_ID,
        panel,
        Test,
 	   	CAST(VALUE_X as VARCHAR) as VALUE,
        NULL as RESULT_SNOMED,
  	 	UNITS,
	  	Abnormal_Flag,
        Result_Status,
        LOINC,
  	  	CAST(RESULT_date as DATE) as  RESULTDTTM,
  		CAST(RECORDED_date as DATE) as RECORDEDDTTM,
  		CAST(provider_ID as VARCHAR(36)) as provider_ID,
        Encounter_ID,
        primary_key  
  FROM SANDBOX.AG_ALB_RESULTS_01;  
