--need a dx table
--need a patients table 

---DX table
create table sandbox.alb_ehr_diagnosis_1 as
--ICD 9
select
GENPATIENTID,
ENCOUNTERID,
PROBLEMID,
ICD9,
NAME,
'ICD-9' as Diagnosis_Code_Type,
TYPE,
CATEGORY,
STATUS,
DIAGNOSISDTTM,
ONSETDTTM,
RESOLVEDDTTM,
RECORDEDDTTM,
GENPROVIDERID
from RWD.ALBATROSS_EHR_problems
where ICD9 is not NULL and ICD9 <> ''
UNION 
--ICD 10
select
GENPATIENTID,
ENCOUNTERID,
PROBLEMID,
ICD10,
NAME,
'ICD-10' as Diagnosis_Code_Type,
TYPE,
CATEGORY,
STATUS,
DIAGNOSISDTTM,
ONSETDTTM,
RESOLVEDDTTM,
RECORDEDDTTM,
GENPROVIDERID
from RWD.ALBATROSS_EHR_problems
where ICD10 is not NULL and ICD10 <> ''
UNION
--ICD 9
select
GENPATIENTID,
ENCOUNTERID,
PROBLEMID,
SNOMED,
NAME,
'SNOMED' as Diagnosis_Code_Type,
TYPE,
CATEGORY,
STATUS,
DIAGNOSISDTTM,
ONSETDTTM,
RESOLVEDDTTM,
RECORDEDDTTM,
GENPROVIDERID
from RWD.ALBATROSS_EHR_problems
where SNOMED is not NULL and SNOMED <> ''
UNION
--name only
select
GENPATIENTID,
ENCOUNTERID,
PROBLEMID,
NULL as empty,
NAME,
'NA' as Diagnosis_Code_Type,
TYPE,
CATEGORY,
STATUS,
DIAGNOSISDTTM,
ONSETDTTM,
RESOLVEDDTTM,
RECORDEDDTTM,
GENPROVIDERID
from RWD.ALBATROSS_EHR_problems
where (ICD9 is  NULL or ICD9 <> '') AND
	(ICD10 is  NULL or ICD10 <> '') AND
	(SNOMED is  NULL or SNOMED <> '') 
;

-------------------------------PELICAN DX------------------------

create table sandbox.transcript_dx as
select
b.patient_id,
b.provider_id,
a.transcript_id,
a.diagnosis_id
from RWD.Pelican_transcript_diagnosis a
inner join rwd.pelican_transcript b
	on a.transcript_id = b.transcript_id;

--ICD9
create table sandbox.pelican_dx_icd9 as 
select
	c.patient_id as genpatientid,
	c.transcript_id as encounterid,
	diagnosis_id,
	icd9,
	NULL as name,
	'ICD-9' as Diagnosis_Code_Type,
	NULL as type,
	NULL as category,
	case when b.IS_active = true then 'Active'
		when b.IS_active = false then 'Inactive'
		else NULL
	end as status,
	NULL as diagnosisdate,
	b.start_date as onsetdate,
	b.stop_date as resolveddate,
	b.created_at as recordeddate,
	c.provider_id as providerid,
	
FROM RWD.PELICAN_diagnosis_ICD9 a
INNER JOIN RWD.Pelican_diagnosis b
	on a.diagnosis_id = b.diagnosis_id
INNER JOIN sandbox.transcript_dx c 
	on b.diagnosis_id = c.diagnosis_id;
	
--ICD10
create table sandbox.pelican_dx_icd10 as 
select
	c.patient_id as genpatientid,
	c.transcript_id as encounterid,
	diagnosis_id,
	icd10,
	NULL as name,
	'ICD-10' as Diagnosis_Code_Type,
	NULL as type,
	NULL as category,
	case when b.IS_active = true then 'Active'
		when b.IS_active = false then 'Inactive'
		else NULL
	end as status,
	NULL as diagnosisdate,
	b.start_date as onsetdate,
	b.stop_date as resolveddate,
	b.created_at as recordeddate,
	c.provider_id as providerid,

FROM RWD.PELICAN_diagnosis_ICD10 a
INNER JOIN RWD.Pelican_diagnosis b
	on a.diagnosis_id = b.diagnosis_id
INNER JOIN sandbox.transcript_dx c 
	on b.diagnosis_id = c.diagnosis_id;	

--ICD10
create or replace table sandbox.pelican_dx_snomed as 
select
	c.patient_id as genpatientid,
	c.transcript_id as encounterid,
	a.diagnosis_id,
	concept_id,
	NULL as name,
	'SNOMED' as Diagnosis_Code_Type,
	NULL as type,
	NULL as category,
	case when b.IS_active = true then 'Active'
		when b.IS_active = false then 'Inactive'
		else NULL
	end as status,
	NULL as diagnosisdate,
	b.start_date as onsetdate,
	b.stop_date as resolveddate,
	b.created_at as recordeddate,
	c.provider_id as providerid

FROM RWD.PELICAN_diagnosis_snomed a
INNER JOIN RWD.Pelican_diagnosis b
	on a.diagnosis_id = b.diagnosis_id
INNER JOIN sandbox.transcript_dx c 
	on b.diagnosis_id = c.diagnosis_id
where a.source = 'original';	
	
    
    
create or replace table sandbox.pelican_dxes as
	select * from sandbox.pelican_dx_icd9
	UNION ALL
	select * from sandbox.pelican_dx_icd10
    UNION ALL
    select 
      GENPATIENTID,
      ENCOUNTERID,
      DIAGNOSIS_ID,
      cast(concept_id as varchar),
      NAME,
      DIAGNOSIS_CODE_TYPE,
      TYPE,
      CATEGORY,
      STATUS,
      DIAGNOSISDATE,
      ONSETDATE,
      RESOLVEDDATE,
      RECORDEDDATE,
      PROVIDERID
    from sandbox.pelican_dx_snomed;

create or replace table sandbox.alb_pel_problems as
	select 
        , * from sandbox.pelican_dxes
	UNION ALL
	select 
        'alb' as datasource,
        cast(GENPATIENTID as varchar),
        ENCOUNTERID,
        PROBLEMID,
        ICD9,
        NAME,
        DIAGNOSIS_CODE_TYPE,
        TYPE,
        CATEGORY,
        STATUS,
        cast(DIAGNOSISDTTM as varchar),
        ONSETDTTM,
        RESOLVEDDTTM,
        cast(RECORDEDDTTM as date),
        cast(GENPROVIDERID as varchar)
    from sandbox.alb_ehr_diagnosis_1;


select count(*) from sandbox.alb_ehr_diagnosis_1
--	
8,105,753,911


-----------------------------------------------
create table sandbox.pel_alb_patient as
select distinct
	a.patient_id,
	a.birth_year,
	NULL as deceased,
	a.gender,
	e.race_name,
	a.ethnicity,
	a.zip,
	a.state,
	f.description,
	d.last_modified,
	b.ENCRYPTED_KEY_1,
	b.ENCRYPTED_KEY_2
from rwd.pelican_patient a
left join rwd.pelican_deid b
	on a.patient_id = b.patient_id
left join rwd.pelican_patient_race c
	on a.patient_id = c.patient_id
inner join rwd.pelican_race e
	on c.race_id = e.race_id
left join rwd.pelican_patient_smoke d
	on a.patient_id = d.patient_id
inner join rwd.pelican_smoke f
	on d.smoke_id = f.smoke_id;

----Problems final table ignore the patient stuff in this sheet
create table sandbox.alb_pel_problems as
	select
      cast (GENPATIENTID as varchar) as patient_id,
      ENCOUNTERID as encounter_id,
      PROBLEMID as problem_id,
      ICD9 as Diagnosis_Code,
      Name,
      DIAGNOSIS_CODE_TYPE,
      TYPE,
      CATEGORY,
      STATUS,
      DIAGNOSISDTTM as diagnosis_date,
      cast(ONSETDTTM as DATE) as onset_date,
      cast(RESOLVEDDTTM as DATE) as resolved_date,
      cast(RECORDEDDTTM as date) as recorded_date,
      cast(GENPROVIDERID as varchar) as provider_id
	from sandbox.alb_ehr_diagnosis_1
UNION ALL
	select * 
    from sandbox.pelican_dxes;
    
    
