---PATIENTS
-----------------------------------------------
create or replace table sandbox.pel_alb_patient_1 as
select distinct
	a.patient_id,
	a.birth_year,
	NULL as deceased,
	a.gender,
	e.race_name,
	a.ethnicity,
	a.zip,
	a.state,
	b.ENCRYPTED_KEY_1,
	b.ENCRYPTED_KEY_2
from rwd.pelican_patient a
left join rwd.pelican_deid b
	on a.patient_id = b.patient_id
left join rwd.pelican_patient_race c
	on a.patient_id = c.patient_id
inner join rwd.pelican_race e
	on c.race_id = e.race_id;

create or replace table sandbox.pel_alb_patient_2 as
select 
    patient_id, 
    max(last_modified) as max_modified_date
from rwd.pelican_patient_smoke
group by patient_id;
 
create or replace table sandbox.pel_alb_patient_3 as
select
    a.patient_id,
    b.last_modified,
    f.description
from sandbox.pel_alb_patient_2 a
inner join rwd.pelican_patient_smoke b
    on a.patient_id = b.patient_id
    and a.max_modified_date = b.last_modified
inner join rwd.pelican_smoke f
    on b.smoke_id = f.smoke_id;
    
create or replace table sandbox.pel_alb_patient_4 as
select
	a.patient_id,
	a.birth_year,
	NULL as deceased,
	a.gender,
	a.race_name,
	a.ethnicity,
	a.zip,
	a.state,
	b.description as smoking_status,
	b.last_modified as smoke_status_last_modified,
	a.ENCRYPTED_KEY_1,
	a.ENCRYPTED_KEY_2
from sandbox.pel_alb_patient_1 a
left join sandbox.pel_alb_patient_3 b
	on a.patient_id = b.patient_id;


create or replace table sandbox.pelican_alb_patients as
	select * from sandbox.pel_alb_patient_4
	UNION
	select
		cast(GENPATIENTID as varchar),
		DOBYEAR,
		DECEASEDFLAG,
		GENDER,
		RACE,
		ETHNICITY1,
		ZIP3,
		STATE_X,
		SMOKINGSTATUSFLAG,
		LASTUPDATEDTTM,
		ENCRYPTED_KEY_1,
		ENCRYPTED_KEY_2
	from rwd.albatross_ehr_patients; 
