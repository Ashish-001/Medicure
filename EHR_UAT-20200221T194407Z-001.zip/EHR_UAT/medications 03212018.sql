create or replace temp table sandbox.pelican_transcriptionprescriptiontest as
select distinct l.*
from rwd.pelican_transcript_prescription l
inner join rwd.pelican_prescription r
    on l.prescription_id = r.prescription_id;

select count(*) from sandbox.pelican_transcriptionprescriptiontest
--	192,420,066

create or replace table sandbox.pelican_alb_meds1 as
select distinct 'pf' as datasource
, case when dispensed_as_written = TRUE then 'Y' when dispensed_as_written = FALSE then 'N' else NULL end as daw
, prescription.days_supply as two
, prescription.days_supply as three
, c_dose_amount || ' ' || coalesce(c_dose_amount_unit,'') as four
, cast(prescription.stop_date as TIMESTAMP_NTZ(9)) as five
, case when erx = 1 then 'Y' when erx = 0 then 'N' else NULL end as six
, doseform as seven
, frequency || ' '  || coalesce(c_frequency,'') as eight
, case when generic_name is not null then 'Y' else NULL end as nine
, prescription.patient_id
, prescription.provider_id
, cast(current_date() as timestamp_ntz(9)) as twelve
, prescription.prescription_id
, medication.trade_name
, prescription.medication_id
, prescription.diagnosis_id
, cast(prescription.c_quantity as varchar()) as seventeen
, transcript_prescription.last_modified
, prescription.num_refills
, medication.route
, random(10000) as twoone
, cast(prescription.start_date as TIMESTAMP_NTZ(9)) as twotwo
, is_active
, medication.strength
, prescription.unit
, max(transcript_prescription.last_modified) as twothree
,transcript_id
from rwd.pelican_prescription prescription
left outer join rwd.pelican_medication medication
    on prescription.medication_id = medication.medication_id
left outer join sandbox.pelican_transcriptionprescriptiontest transcript_prescription
    on prescription.prescription_id = transcript_prescription.prescription_id
    group by case when dispensed_as_written = TRUE then 'Y' when dispensed_as_written = FALSE then 'N' else NULL end
      , prescription.days_supply
      , prescription.days_supply
      , c_dose_amount || ' ' || coalesce(c_dose_amount_unit,'')
      , cast(prescription.stop_date as TIMESTAMP_NTZ(9))
      , case when erx = 1 then 'Y' when erx = 0 then 'N' else NULL end
      , doseform
      , frequency || ' '  || coalesce(c_frequency,'')
      , case when generic_name is not null then 'Y' else NULL end
      , prescription.patient_id
      , prescription.provider_id
      , cast(current_date() as timestamp_ntz(9))
      , prescription.prescription_id
      , medication.trade_name
      , prescription.medication_id
      , prescription.diagnosis_id
      , cast(prescription.c_quantity as varchar())
      , transcript_prescription.last_modified
      , prescription.num_refills
      , medication.route
      , random(10000)
      , cast(prescription.start_date as TIMESTAMP_NTZ(9))
      , is_active
      , medication.strength
      , prescription.unit
      ,transcript_id;

/*5 test union all*/
create or replace table sandbox.alb_pel_medications as
select 'alb' as datasource
, DAWFLAG as dispensed_as_written_flag
, cast(DAYSTOTAKE as varchar) as days_to_take
, cast(DAYSUPPLY as varchar) as days_supply
, DOSE
, ENDDTTM as end_date
, ERXTRANSMITTEDFLAG as erx_transmitted_flage
, FORM 
, FREQUENCY
, GENERICAVAILABLEFLAG as generic_available_flage
, cast(GENPATIENTID as varchar()) as patient_id
, cast(GENPROVIDERID as varchar()) as provider_id
, cast(current_date() as timestamp_ntz(9)) as INSERTED_DATE
, MEDID as med_id
, NAME
, NDC
, PROBLEMID as problem_id
, QUANTITYTODISPENSE as quantity_to_dispense
, RECORDEDDTTM as recorded_date
, cast(REFILLS as varchar()) as refills
, ROUTEOFADMIN as route_of_admin
, NULL as RW_NUM
, STARTDTTM as start_date
, STATUS
, STRENGTH
, UNITS
, NULL as UPDATED_DATE
, encounterid as encounter_id
from RWD.ALBATROSS_EHR_medications
union all
select * from sandbox.pelican_alb_meds1;

create or replace table sandbox.alb_pel_medications_2 as
select
encounter_id
,dispensed_as_written_flag
,days_to_take
,days_supply
, DOSE
,end_date
,erx_transmitted_flage as erx_transmitted_flag
, FORM 
, FREQUENCY
,generic_available_flage as generic_available_flag
, patient_id
, provider_id
, INSERTED_DATE
, med_id
, NAME
, NDC
, problem_id
,  quantity_to_dispense
, recorded_date
, refills
, route_of_admin
, start_date
, STATUS
, STRENGTH
, UNITS
from sandbox.alb_pel_medications;


select count(*) from sandbox.pelican_alb_meds1
--	469,143,153
select count(*) from sandbox.pelican_alb_medications
--2,724,312,795

select count(*) from RWD.ALBATROSS_EHR_medications
--	2,255,169,642

select * from sandbox.pelican_alb_medications
where datasource != 'alb' limit 10

---PELICAN DX REMOVE ME
create table sandbox.transcript_dx as
select
b.patient_id,
b.provider_id,
a.transcript_id,
a.diagnosis_id
from RWD.Pelican_transcript_diagnosis a
inner join rwd.pelican_transcript b
	on a.transcript_id = b.transcript_id;

--ICD9
create table sandbox.pelican_dx_icd9 as 
select
	c.patient_id as genpatientid,
	c.transcript_id as encounterid,
	a.diagnosis_id,
	a.icd9,
	NULL as name,
	'ICD-9' as Diagnosis_Code_Type,
	NULL as type,
	NULL as category,
	case when b.IS_active = true then 'Active'
		when b.IS_active = false then 'Inactive'
		else NULL
	end as status,
	NULL as diagnosisdate,
	b.start_date as onsetdate,
	b.stop_date as resolveddate,
	b.created_at as recordeddate,
	c.provider_id as providerid
	
FROM RWD.PELICAN_diagnosis_ICD9 a
INNER JOIN RWD.Pelican_diagnosis b
	on a.diagnosis_id = b.diagnosis_id
INNER JOIN sandbox.transcript_dx c 
	on b.diagnosis_id = c.diagnosis_id;
	
--ICD10
create table sandbox.pelican_dx_icd10 as 
select
	c.patient_id as genpatientid,
	c.transcript_id as encounterid,
	a.diagnosis_id,
	a.icd10,
	NULL as name,
	'ICD-10' as Diagnosis_Code_Type,
	NULL as type,
	NULL as category,
	case when b.IS_active = true then 'Active'
		when b.IS_active = false then 'Inactive'
		else NULL
	end as status,
	NULL as diagnosisdate,
	b.start_date as onsetdate,
	b.stop_date as resolveddate,
	b.created_at as recordeddate,
	c.provider_id as providerid
FROM RWD.PELICAN_diagnosis_ICD10 a
INNER JOIN RWD.Pelican_diagnosis b
	on a.diagnosis_id = b.diagnosis_id
INNER JOIN sandbox.transcript_dx c 
	on b.diagnosis_id = c.diagnosis_id;	

--SNOMED
create table sandbox.pelican_dx_snomed as 
select
	c.patient_id as genpatientid,
	c.transcript_id as encounterid,
	a.diagnosis_id,
	a.concept_id,
	NULL as name,
	'SNOMED' as Diagnosis_Code_Type,
	NULL as type,
	NULL as category,
	case when b.IS_active = true then 'Active'
		when b.IS_active = false then 'Inactive'
		else NULL
	end as status,
	NULL as diagnosisdate,
	b.start_date as onsetdate,
	b.stop_date as resolveddate,
	b.created_at as recordeddate,
	c.provider_id as providerid

FROM RWD.PELICAN_diagnosis_snomed a
INNER JOIN RWD.Pelican_diagnosis b
	on a.diagnosis_id = b.diagnosis_id
INNER JOIN sandbox.transcript_dx c 
	on b.diagnosis_id = c.diagnosis_id;	
	
create table sandbox.pelican_dxes as
	select * from sandbox.pelican_dx_icd9
	UNION ALL
	select * from sandbox.pelican_dx_icd10
    UNION ALL
    select 
      GENPATIENTID,
      ENCOUNTERID,
      DIAGNOSIS_ID,
      cast(concept_id as varchar),
      NAME,
      DIAGNOSIS_CODE_TYPE,
      TYPE,
      CATEGORY,
      STATUS,
      DIAGNOSISDATE,
      ONSETDATE,
      RESOLVEDDATE,
      RECORDEDDATE,
      PROVIDERID
    from sandbox.pelican_dx_snomed;

    
create table sandbox.pelican_alb_diagnoses_problems
	select datasource = 'pf', * from sandbox.pelican_dxes
	UNION ALL
	select datasource = 'alb', * from sandbox.alb_ehr_diagnosis_1;
