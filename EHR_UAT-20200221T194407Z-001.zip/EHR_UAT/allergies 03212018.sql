create table sandbox.alb_allergies as
select 
  GENPATIENTID	as Patient_ID,
  ENCOUNTERID	as Encounter_ID,
  ALLERGYID	as Allergy_ID,
  VERSIONID	as Version_ID,
  AUDITDATAFLAG	as Audit_Flag,
  NAME	as Allergy_Name,
  TYPE	as Allergy_Type,
  STATUS	as Allergy_Status,
  REACTIONS	as Reactions,
  NDC	as NDC,
  DDI	as DDI,
  GPI	as GPI,
  RXNORM	as Rxnorm,
  SNOMED	as Snomed,
  REACTIONDTTM	as Reaction_Date,
  RECORDEDDTTM	as Recorded_Date,
  NULL	as Start_Date,
  NULL	as Stop_Date,
  GENPROVIDERID	as Provider_ID,
  PRIMARYKEY	as Primary_Key
from RWD.ALBATROSS_EHR_ALLERGIES;

create table sandbox.pel_allergies as
select 
  patient_id	as Patient_ID,
  a.transcript_id	as Encounter_ID,
  b.allergen_id	as Allergy_ID,
  NULL	as Version_ID,
  NULL	as Audit_Flag,
  c.description	as Allergy_Name,
  NULL	as Allergy_Type,
  b.is_active	as Allergy_Status,
  NULL	as Reactions,
  b.medication_id	as NDC,
  NULL	as DDI,
  NULL	as GPI,
  NULL	as Rxnorm,
  NULL	as Snomed,
  NULL	as Reaction_Date,
  b.created_at	as Recorded_Date,
  b.start_date	as Start_Date,
  b.stop_date	as Stop_Date,
  NULL	as Provider_ID,
  NULL	as Primary_Key

from pelican_transcript_allergy a
inner join pelican_allergy b
    on a.allergy_id = b.allergy_id
left join pelican_allergen c
    on b.allergen_id = c.allergen_id;

create table sandbox.pelican_alb_allergies as
select
  cast (PATIENT_ID as varchar) as PATIENT_ID,
  ENCOUNTER_ID,
  ALLERGY_ID,
  VERSION_ID,
  ALLERGY_NAME,
  ALLERGY_TYPE,
  ALLERGY_STATUS,
  REACTIONS,
  NDC,
  DDI,
  GPI,
  RXNORM,
  SNOMED,
  REACTION_DATE,
  cast (RECORDED_DATE as date) as RECORDED_DATE,
  cast (START_DATE as date) as START_DATE,
  cast (STOP_DATE as date) as STOP_DATE,
  cast (PROVIDER_ID as varchar) as PROVIDER_ID,
  PRIMARY_KEY
from sandbox.alb_allergies
    UNION ALL
select
  PATIENT_ID,
  ENCOUNTER_ID,
  ALLERGY_ID,
  cast (VERSION_ID as number) as VERSION_ID,
  ALLERGY_NAME,
  ALLERGY_TYPE,
  case when ALLERGY_STATUS = true then 'true' else 'false' end as ALLERGY_STATUS,
  REACTIONS,
  NDC,
  cast (DDI as number) as DDI,
  GPI,
  RXNORM,
  SNOMED,
  cast (REACTION_DATE as date) as REACTION_DATE,
  RECORDED_DATE,
  START_DATE,
  STOP_DATE,
  PROVIDER_ID,
  PRIMARY_KEY
from sandbox.pel_allergies;
 
