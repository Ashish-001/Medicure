------Encounters
create table sandbox.alb_encounter as
select 
  GENPATIENTID	as Patient_ID,
  ENCOUNTERID	as Encounter_ID,
  VERSIONID	as Version_ID,
  AUDITDATAFLAG	as Audit_Flag,
  TYPE	as Type,
  ENCOUNTERDTTM	as Encounter_DATE,
  RECORDEDDTTM	as Recorded_Date,
  GENBILLINGPROVIDERID	as Billing_Provider_ID,
  GENRENDERINGPROVIDERID	as Rendering_Provider_ID,
  GENPROVIDERID	as Provider_ID,
  PRIMARYKEY	as Primary_KEY
from RWD.ALBATROSS_EHR_encounters;

create table sandbox.pel_encounter as
select 
    a.patient_id	as Patient_ID,
    a.transcript_id	as Encounter_ID,
    NULL	as Version_ID,
    NULL	as Audit_Flag,
    NULL	as Type,
    a.dos	as Encounter_DATE,
    a.last_modified	as Recorded_Date,
    NULL	as Billing_Provider_ID,
    NULL	as Rendering_Provider_ID,
    a.provider_id	as Provider_ID,
    NULL	as Primary_KEY
from pelican_transcript a;

create table sandbox.alb_pel_encounter as
select
  cast (PATIENT_ID as varchar) as PATIENT_ID,
  ENCOUNTER_ID,
  cast (VERSION_ID as varchar) as VERSION_ID,
  TYPE,
  ENCOUNTER_DATE,
  cast (RECORDED_DATE as date) as RECORDED_DATE,
  cast (BILLING_PROVIDER_ID as varchar) as BILLING_PROVIDER_ID,
  cast (RENDERING_PROVIDER_ID as varchar) as RENDERING_PROVIDER_ID,
  cast (PROVIDER_ID as varchar) as PROVIDER_ID,
  PRIMARY_KEY
from sandbox.alb_encounter
UNION ALL
select
  PATIENT_ID,
  ENCOUNTER_ID,
  VERSION_ID,
  TYPE,
  ENCOUNTER_DATE,
  RECORDED_DATE,
  BILLING_PROVIDER_ID,
  RENDERING_PROVIDER_ID,
  PROVIDER_ID,
  PRIMARY_KEY
from sandbox.pel_encounter;



------PROVIDERS
create or replace table sandbox.alb_provider as
select 
    GENPROVIDERID	as Provider_ID,
    NPI_TITLE	as NPI_TITLE,
    NPI_GENDER	as NPI_GENDER,
    NPI_TXNCODE	as NPI_TXNCODE,
    NPI_TXNCLASS	as NPI_TXNCLASS,
    NPI_TXNTYPE	as NPI_TXNTYPE,
    NPI_TXNSPECIALTY	as NPI_TXNSPECIALTY,
    NPI_TPVERIFIEDSPECIALTY	as NPI_TPVERIFIEDSPECIALTY,
    NPI_DOBYEAR	as NPI_DOBYEAR,
    NPI_STATE	as NPI_STATE,
    SPECIALTY	as SPECIALTY,
    CREDENTIAL	as CREDENTIAL,
    TYPE	as TYPE,
    PCPFLAG	as PCPFLAG,
    STATE_X	as STATE_X,
    INACTIVEFLAG	as Active_Flage,
    LASTUPDATEDTTM	as last_updated_date,
    PRIMARYKEY	as primary_key
from RWD.ALBATROSS_EHR_providers;


create or replace table sandbox.pel_provider as
select 
    provider_ID	as Provider_ID,
    NULL	as NPI_TITLE,
    NULL	as NPI_GENDER,
    NULL	as NPI_TXNCODE,
    NULL	as NPI_TXNCLASS,
    NULL	as NPI_TXNTYPE,
    NULL	as NPI_TXNSPECIALTY,
    NULL	as NPI_TPVERIFIEDSPECIALTY,
    NULL	as NPI_DOBYEAR,
    NULL	as NPI_STATE,
    b.name	as SPECIALTY,
    NULL	as CREDENTIAL,
    b.provider_type	as TYPE,
    NULL	as PCPFLAG,
    NULL	as STATE_X,
    a.is_active	as Active_Flage,
    a.created_at	as last_updated_date,
    NULL	as primary_key
from pelican_provider a
left join pelican_specialty b
    on a.primary_specialty_id = b.specialty_id;
    
    
create or replace table sandbox.alb_pel_provider as
select
  PROVIDER_ID,
  NPI_TITLE,
  NPI_GENDER,
  NPI_TXNCODE,
  NPI_TXNCLASS,
  NPI_TXNTYPE,
  NPI_TXNSPECIALTY,
  NPI_TPVERIFIEDSPECIALTY,
  cast (NPI_DOBYEAR as number) as NPI_DOBYEAR,
  NPI_STATE,
  SPECIALTY,
  CREDENTIAL,
  TYPE,
  PCPFLAG,
  STATE_X,
  case when active_flage = true then 'true' else false end as active_flag,
  LAST_UPDATED_DATE,
  PRIMARY_KEY
from sandbox.pel_provider
union all
select
  cast (PROVIDER_ID as varchar) as PROVIDER_ID,
  NPI_TITLE,
  NPI_GENDER,
  NPI_TXNCODE,
  NPI_TXNCLASS,
  NPI_TXNTYPE,
  NPI_TXNSPECIALTY,
  NPI_TPVERIFIEDSPECIALTY,
  NPI_DOBYEAR,
  NPI_STATE,
  SPECIALTY,
  CREDENTIAL,
  TYPE,
  PCPFLAG,
  STATE_X,
  ACTIVE_FLAGe,
  cast (LAST_UPDATED_DATE as date) as LAST_UPDATED_DATE,
  PRIMARY_KEY
from sandbox.alb_provider;






