
/////////////////////////Condor Pharmacy Claims//////////////////////////////////
drop table sandbox.tbl_condor_pharmacy_biogen_techfi_DK_ID
Create table sandbox.tbl_condor_pharmacy_biogen_techfi_DK_ID as
select
'CondorPhar' as Source,
trim(emdeon_tdr_claimid_or_uow_agn) as Claim_number,
trim(patient_suffix) as patient_Suffix,
(Case when trim(PATIENT_GENDER_CODE) = '1' then 'M'
      when trim(Patient_Gender_code) = '2' then 'F' 
      else 'X' end) as Patient_Gender,
case when PATIENT_ZIP_OR_POSTAL_ZONE is null then patient_suffix
            else patient_suffix||PATIENT_ZIP_OR_POSTAL_ZONE end as Patient_ID,
trim(DATE_OF_BIRTH) as Patient_DOB,
trim(product_or_service_id) as NDC,
trim(days_supply) as days_supply,
trim(date_of_service) as Service_Date
from rwd.pharmacy_record
where trim(product_or_service_id) in ('64406000703','64406000501','64406000602')
and trim(PATIENT_SUFFIX) <> ''
and upper(PATIENT_SUFFIX) not like 'XXX -%'
and upper(PATIENT_SUFFIX) <> 'NULL'
and upper(trim(RESPONSE_CODE)) = 'P';

////////////////////////////////condor Claims/////////////////////////////////////
drop table sandbox.tbl_Condor_biogen_tecfi_DK_ID_temp
Create table sandbox.tbl_Condor_biogen_tecfi_DK_ID_Temp as
select
trim(d.claim_number) as Claim_number,
trim(d.ndc) as NDC,
trim(d.service_from) as service_from
from rwd.service_record d
where trim(d.ndc) in ('64406000703','64406000501','64406000602')

drop table sandbox.tbl_Condor_biogen_tecfi_DK_ID
Create table sandbox.tbl_Condor_biogen_tecfi_DK_ID as
select 
'Condor' as Source,
trim(c.claim_number) as Claim_number,
trim(c.patient_suffix) as patient_Suffix,
trim(c.PATIENT_GENDER) as patient_gender,
case when c.MEMBER_ADR_ZIP is null then c.patient_suffix
            else c.patient_suffix||c.MEMBER_ADR_ZIP end as Patient_ID,
trim(C.PATIENT_DOB) as PATIENT_DOB,
trim(d.ndc) as NDC,
'0' as days_supply,
coalesce(trim(c.statement_from) ,trim(d.service_from)) as Service_Date
from rwd.claim_record c
inner join sandbox.tbl_Condor_biogen_tecfi_DK_ID_Temp d
on trim(c.claim_number)=trim(d.claim_number)
where c.PATIENT_SUFFIX is not null
and trim(c.PATIENT_SUFFIX) <> ''
and upper(c.PATIENT_SUFFIX) not like 'XXX -%'
and upper(c.PATIENT_SUFFIX) <> 'NULL'

////////////////////Albatross Medical////////////////
drop table sandbox.tbl_Albatross_biogen_tecfi_DK_ID
Create table sandbox.tbl_Albatross_biogen_tecfi_DK_ID as
select 
'Ablatross' as Source, 
trim(a.entityid) as Claim_number,
trim(a.patientsuffix) as patient_Suffix,
trim(a.PATIENTSEX) as Patient_gender,
case when a.PATIENTZIPCODE is null then a.patientsuffix
            else a.patientsuffix||a.PATIENTZIPCODE end as Patient_ID,
trim(a.PATIENTDOB) as PATIENT_DOB,
trim(b.ndccode) as NDC,
'0' as days_supply,
trim(b.servicefromdate) as Service_Date
from rwd.claims_header a
inner join rwd.claims_detail b
on trim(a.entityid)=trim(b.entityid)
where trim(b.ndccode) in ('64406000703','64406000501','64406000602')
and a.PATIENTSUFFIX is not null
and trim(a.PATIENTSUFFIX) <> ''
and upper(a.PATIENTSUFFIX) not like 'XXX -%'
and upper(a.PATIENTSUFFIX) <> 'NULL'

//////////////////Vulture Medical////////////////////////////
drop table sandbox.tbl_vulture_biogen_tecfi_DK_ID;
Create table sandbox.tbl_vulture_biogen_tecfi_DK_ID as
select 
'vulture' as source,
trim(hed.claimid) as Claim_number,
trim(pat.key1) as Patient_suffix,
trim(pat.sex) as patient_gender,
case when pat.ZIP3 is null then pat.key1
            else pat.key1||pat.ZIP3 end as Patient_ID,
trim(pat.DATEOFBIRTH) as Patient_DOB,
trim(ser.DrugCode) as NDC, 
'0' as days_supply,
coalesce(hed.startdate, ser.servicestart) as Service_Date
from  rwd.ABILITY_VWHEADER                          as hed      
inner join rwd.ABILITY_VWserviceline                 as ser      on ser.claimid = hed.claimid
left join rwd.ABILITY_VWPATIENT                     as pat      on ser.claimid = pat.claimid
where trim(ser.DrugCode) in ('64406000703','64406000501','64406000602')
and trim(pat.key1) is not NULL
and trim(upper(pat.key1)) <> 'NULL'
and trim(upper(pat.key1)) not like 'XXX -%'
and trim(pat.key1) <> '';

////////////////////////////////////////////EHR ///////////////////////////////////////////////////////////////////
drop table  sandbox.tbl_albatross_EHR_Biogen_tecfi_ID
create table sandbox.tbl_albatross_EHR_Biogen_tecfi_ID as
select
    'EHR' as source,
    null as claim_number,
    trim(map.patientsuffix) as Patient_suffix,
    trim(pat.Gender) as Patient_Gender,
    case when pat.ZIP3 is null then trim(map.patientsuffix)
            else trim(map.patientsuffix)||pat.ZIP3 end as Patient_ID,
    trim(pat.DOByear) as patient_DOB,
    trim(med.NDC) as NDC,
    trim(med.daysupply) as days_supply,
    cast(med.recordeddttm as date) as Final_Date
from rwd.medications med
inner join rwd.patients pat on med.genpatientid = pat.genpatientid
inner join rwd.mappingdata map on  map.genpatientid = med.genpatientid
where med.genpatientID is not null
        and TRIM(map.PATIENTSUFFIX) NOT LIKE 'XXX -%'
        //and left(upper(trim(med.errorflag)),1) != 'Y'
        and (trim(med.NDC) in ('64406000703','64406000501','64406000602') or trim(lower(med.name)) like '%tecfidera%')
        and (lower(trim(med.STATUS)) = ''
             or lower(trim(med.STATUS)) = 'active'
             or lower(trim(med.STATUS)) = 'administered'
             or lower(trim(med.STATUS)) like '%complete%'
             or lower(trim(med.STATUS)) = 'continued'
             or lower(trim(med.STATUS)) = 'filled rx'
             or lower(trim(med.STATUS)) = 'hold for'
             or lower(trim(med.STATUS)) = 'in progress'
             or lower(trim(med.STATUS)) = 'ordered'
             or lower(trim(med.STATUS)) = 'pending'
             or lower(trim(med.STATUS)) = 'resulted'
             or lower(trim(med.STATUS)) like '%discontinued%' 
             or lower(trim(med.STATUS)) like '%need information%'
            )
        and lower(trim(med.PRESCRIBEACTION)) not like '%cancel%'
///////////////////Combining All Medical Claims and Pharmacy Claims///////////////////
drop table sandbox.tbl_biogen_tecfi_combined_DK_ID;
create table sandbox.tbl_biogen_tecfi_combined_DK_ID as 
(
Select * from sandbox.tbl_condor_pharmacy_biogen_techfi_DK_ID
  union all
Select * from sandbox.tbl_Condor_biogen_tecfi_DK_ID
  union all
Select * from sandbox.tbl_Albatross_biogen_tecfi_DK_ID
  union all
Select * from sandbox.tbl_vulture_biogen_tecfi_DK_ID
  union all
select * from sandbox.tbl_albatross_EHR_Biogen_tecfi_ID
);


////////////////////extracting min date & max date for a patient///////////////////

Drop table sandbox.tbl_biogen_tecfi_combined_DK_ID1;
Create table sandbox.tbl_biogen_tecfi_combined_DK_ID1 as
select distinct patient_suffix, service_date, days_supply*1 as days_supply, 
        max(service_date) over (partition by patient_suffix) End_Date,
        min(service_date) over (partition by patient_suffix) start_date 
from sandbox.tbl_biogen_tecfi_combined_DK_ID;


Select count(distinct patient_suffix) from sandbox.tbl_biogen_tecfi_combined_DK_ID1 

//////////////code for continuous enrollment
drop table sandbox.tbl_biogen_tecfi_combined_DK_ID4_30 ;
Create table sandbox.tbl_biogen_tecfi_combined_DK_ID4_30 as
Select *, lead(Service_Date,1) over( partition by patient_suffix order by service_date) as Lead_Service_Date
From sandbox.tbl_biogen_tecfi_combined_DK_ID1;

drop table sandbox.tbl_biogen_tecfi_combined_DK_ID5_30 ;
Create table sandbox.tbl_biogen_tecfi_combined_DK_ID5_30 as
select *, datediff( dd, service_date, (case when lead_service_date is null then dateadd(dd,(case when days_supply is null then 0 else days_supply end), service_date) 
                                       else lead_service_date  end)) as consecutive_diff ,
case when datediff( dd, service_date, (case when lead_service_date is null then dateadd(dd, (case when days_supply is null then 0 else days_supply end), service_date) 
                                       else lead_service_date  end)) <= (case when days_supply is null then 0 else days_supply end) + 15 then  'Y'
else 'N' end as is_continuous_flag
from sandbox.tbl_biogen_tecfi_combined_DK_ID4_30;

/////change the days of buffer in above table 15, 30, 45, 60

Update  sandbox.tbl_biogen_tecfi_combined_DK_ID5_30
Set is_continuous_flag = 'N'
where Service_Date = End_Date;

drop table sandbox.tbl_biogen_tecfi_combined_DK_ID10_a30;
create table   sandbox.tbl_biogen_tecfi_combined_DK_ID10_a30 as
Select A.*, sum(case when days_supply is null then 0 else days_supply end) 
             over(partition by patient_suffix order by service_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cummu_days_supply
from sandbox.tbl_biogen_tecfi_combined_DK_ID5_30 A;

drop table sandbox.tbl_biogen_tecfi_combined_DK_ID10_b30;
Create table sandbox.tbl_biogen_tecfi_combined_DK_ID10_b30 as
select patient_suffix,is_continuous_flag,service_date,cummu_days_supply 
from sandbox.tbl_biogen_tecfi_combined_DK_ID10_a30
where is_continuous_flag = 'N';

drop table sandbox.tbl_biogen_tecfi_combined_DK_ID10_c30;
create table  sandbox.tbl_biogen_tecfi_combined_DK_ID10_c30 as
select a.*,(case when (lag(cummu_days_supply) over (partition by patient_suffix  order by service_date)) is null then 0 
            else (lag(cummu_days_supply) over (partition by patient_suffix  order by service_date)) end)as lag_cummu_days_supply
from sandbox.tbl_biogen_tecfi_combined_DK_ID10_b30 A;

drop table sandbox.tbl_biogen_tecfi_combined_DK_ID10_d30;
create table  sandbox.tbl_biogen_tecfi_combined_DK_ID10_d30 as
select a.*,(cummu_days_supply - lag_cummu_days_supply)as diff
from sandbox.tbl_biogen_tecfi_combined_DK_ID10_c30 A;

drop table sandbox.tbl_biogen_tecfi_combined_DK_ID11_30;
Create table sandbox.tbl_biogen_tecfi_combined_DK_ID11_30 as
Select * from sandbox.tbl_biogen_tecfi_combined_DK_ID1 
where patient_suffix in (
Select Distinct patient_suffix from (
    Select patient_suffix, max(diff)  from sandbox.tbl_biogen_tecfi_combined_DK_ID10_d30
    group by 1
    having max(diff) >= 90));

Select count(distinct patient_suffix ) from sandbox.tbl_biogen_tecfi_combined_DK_ID11_30







///////////////////////////////////////////EHR/////////////////////////////////

///////orders table ///////////
drop table sandbox.tbl_biogen_order_EHR_ALC_DK 
create table sandbox.tbl_biogen_order_EHR_ALC_DK as
select 
        trim(a.cpt4) as cpt4,
        trim(a.encounterid) as encounterid,
        trim(a.genpatientid) as genpatientid,
        trim(a.hcpcs) as hcpcs,
        trim(a.inserted_date) as inserted_date,
        trim(a.name) as name,
        trim(a.orderdttm) as orderdttm,
        trim(a.orderid) as orderid,
        trim(a.recordeddttm) as recordeddttm,
        trim(a.rectype) as rectype,
        trim(a.status) as status,
        trim(b.patientsuffix) as patient_suffix
from rwd.orders a
inner join rwd.mappingdata b on trim(a.genpatientid) =trim(b.genpatientid) 
where ((trim(cpt4) in ('85004','85007','85009','85025','80050','86360','86361','86359','85004','85048','86355','86357','86064','86379','86587','88182','88184','88185','88187','88188','88189') 
        or trim(name) in ('LYMPHOCYTE SUB PANEL','PLATELET ANTIBODY$DIRECT FLOW CYTOMETRY','Flow Cytometry of Peripheral Blood','T- AND B-CELL QN BY FLOW CYTOMETRY','Peripheral Blood Flow Cytometry','CD-4 Flow Cytometry','NEUTROPHIL ANTIBODY$FLOW CYTOMETRY',
                          'Leukemia/Lymphoma Flow Cytometry','Flow Cytometry Blood','Flow Cytometry Blood/Bone Marrow (Sendout)','PLATELET AB DIRECT FLOW CYTOMETRY - 5019','Flow Cytometry Report','FLOW CYTOMETRY PANEL','FLOW CYTOMETRY CELL/CYTO/NUC MARKER TC ONLY; IST MARKER',
                          'NEUTROPHIL ANTIBODY FLOW CYTOMETRY','BLOOD CT; RETICULOCYTE CT FLOW CYTOMETRY','Flow Cytometry - Bone Marrow','FLOW CYTOMETRY BLOOD/BM','Flow Cytometry - Whole Blood','Flow Cytometry Blood Acute','BLOOD FLOW CYTOMETRY','Flow Cytometry Cell Surface - Additional Marker',
                          'CHRONIC LYMPHOCYTIC LEUKEMIA/LYMPHOMA PROFILE FLOW CYTOMETRY (99934)','FLOW CYTOMETRY PERIPHERAL BLD','Flow Cytometry (Cell Surface Marker Leuk/Lym)','Platelet Antibody direct Flow Cytometry','Peripheral Blood Flow Cytometry (R/O Leukemia or Lymphoma)',
                          'BONE MARROW FLOW CYTOMETRY','NEUTROPHIL AB FLOW CYTOMETRY','B-Cell QN by Flow Cytometry','Flow Cytometry Bone Marrow','Human leukocyte antigen (HLA) B27 detection by flow cytometry','DISCONTINUED - FLOW CYTOMETRY','FLOW CYTOMETRY (88182)','FLOW CYTOMETRYBLOOD/BONEMARROW',
                          'Lab Auto Diff WBC Count (ABN $27.70)','WBC Count Automated','MANUAL DIFF WBC COUNT','Bl Smear W/Diff Wbc Count','MANUAL DIFF WBC COUNT (85007)','Lab Auto Diff WBC Count','BLOOD CT; AUTOMATED DIFFERENTIAL WBC COUNT','Fecal WBC Count (GPRMC)','Differential WBC Count',
                          'WBC COUNT MANUAL DIFF (85007) **CENTRA LAB** (WBCD)','BLOOD CT; MANUAL DIFF WBC COUNT','MANUAL DIFF WBC COUNT - RELAY HEALTH (85007)','Bl Smear W/O Diff Wbc Count','Lab Auto Diff WBC Count (ABN $25.55)','Differential/Total WBC Count - LabCorp (85007)','Wbc Count',
                          'Differential/Total WBC Count   015173','Differential and Total WBC Count','BL SMEAR W/DIFF WBC COUNT (85007)','Automated diff wbc count','WBC Count and Differential','WBC Count Stool','DIFFERENTIAL/TOTAL WBC COUNT','Lab Auto Diff WBC Count (ABN: $24.55)',
                          'LAB AUTO DIFF WBC COUNT(ABN: $19.55)-85004','DIFFRENTIAL WBC COUNT-BUFFY (85009)','WBC COUNT WITH DIFFERENTIAL (85025)','CSF WBC COUNT WITH DIFFERENTIAL','DISCONTINUED - MANUAL DIFF WBC COUNT (85007)','WBC Count and Diff','WHITE BLOOD COUNT - WBC','COMPLETE BLOOD COUNT WITH AUTO DIFF',
                          'BLOOD COUNT AUTO DIF WBC','CBC/COMPL BLOOD COUNT','xComplete Blood Count','Blood Count (MdCtr)1','CBC Complete Blood Count (85025)','CLINIC WHITE BLOOD COUNT','BLOOD COUNT; AUTO DIFF WBC COUNT','Complete Blood Count Hx HMP','Blood count; red blood cell (RBC) automated',
                          'Complete Blood Count Man Diff','CBC - COMPLETE BLOOD COUNT - 912','White Blood Count 85048','HL Complete Blood Count And Differential','Complete Blood Count Manual Diffs','CBC - Complete Blood Count (85025)','Abc ( Complete Auto Blood Count/ Cbc )','Blood Count White Blood Cell',
                          'Anemia: complete blood count (CBC)','Obstetric panel This panel must include the following: Blood count complete (CBC) automated and automated differential WBC count (85025 or 85027 and 85004) OR Blood count complete (CBC) automated (85027) and appropriate manual differential WBC count (',
                          'White Blood Count /  WBC','BLOOD COUNT;HEMOGRAM & PLATELET CTAUTOMAT& AUTOMAT PART DIFF WBC CT(CBC)','IMA Complete Blood Count CBC','Blood Count (MdCtr)1/Manual Diff','Partial Blood Count','Lab Blood Count Red Blood Cell (ABN $22.45)','COMPLETE BLOOD COUNT (CBC) & Platelets','COMPLETE BLOOD COUNT WITH MANUAL DIFF (74106) - 74106',
                          'XComplete Blood Count with Differential','Blood Count Diff Wbc.Lab (ABN $21.45)','Complete Blood Count + Auto Differential','COMPLETE BLOOD COUNT CBC (NO DIFF)','Lab Blood Count Hematocrit (ABN $27.05)','BLOOD COUNT; HEMOGLOBIN (','COMPLETE BLOOD COUNT W DIFF (CBC W/DIFF)','CBC (COMPLETE BLOOD COUNT) W/DIFFERENTIAL AND PLT',
                          'Blood count; leukocyte (WBC) automated','COMPLETE BLOOD COUNT/PLATELET','BLOOD COUNT; HEMOGRAM & PLATELET COUNT AUTO AUTO COMPLETE DIFFERENTIAL WBC (CBC)','Complete Blood Count without Differential (Hemog','Blood count; blood smear microscopic examination with manual differential WBC count','Complete Blood Count ( CBC ) - GMC',
                          'Blood Count Complete Without Differential (Hemogram)','Complete blood count (CBC) with differential panel','Complete Blood Count w/Auto Diff','BLOOD COUNT W/MANUAL DIFF','WBC (WHITE BLOOD COUNT)','Complete Blood Count without Differential.','CANCELLED COMPLETE BLOOD COUNT','BLOOD COUNT COMPLETE AUTOMATED PROCEDURE (85027)',
                          'Blood Count Diff Wbc.Lab (ABN $25.90)','BLOOD COUNT PLATELET','BLOOD COUNT WITH PLATELET','xComplete Blood Count w/o Differential','COMPLETE BLOOD COUNT & AUTODIF','CMG - Low Blood Counts','HL  Complete Blood Count','COMPLETE BLOOD COUNT CBC (W/ DIFF PLT SMEAR REVIEW) - 20253','COMPLETE BLOOD COUNT&AUTODIF','BLOOD COUNT; COMPLETE (CB',
                          'CBC (Complete Blood Count) with Auto Differential','BLOOD COUNT; HEMATOCRIT (Hct)','COMPLETE BLOOD COUNT - CBC NO DIFF','Complete Blood Count Test (CBC): anemia','COMPLETE BLOOD COUNT  WITH MANUAL DIFF','COMPLETE BLOOD COUNT CBC W DIFF','Complete Blood Count Test (CBC): complete blood cell count','Complete Blood Count w/differential and plt (85025)',
                          'COMPLETE BLOOD COUNT$WITH MANUAL DIFF','Complete Blood Count w Differential Careset','Blood Counts - CBC','(85027) CBC (Complete Blood Count)','BLOOD COUNT','Complete Blood Count Test (CBC): lab test','Complete blood count (hemogram) panel','BLOOD COUNT MANUEL DIFF','BLOOD COUNT HEMOGRAM AND AUTO DIFFIAL','COMPLETE BLOOD COUNT W/RDW',
                          'CBC COMPLETE BLOOD COUNT UC','CBC Complete Blood Count (CBC diff plt)','BLOOD COUNT; HEMOGLOBIN (HGB) (85018)','COMPLETE BLOOD COUNTAUTO DIFF','BLOOD COUNT; HEMATOCRIT (HCT) (85014)','Complete Blood Count W/ Manual Diff','Complete Blood Count w/ Auto Diff.- QUEST','CBC Complete Blood Count w/ Diff (CLH 0360)','BLOOD COUNT COMPLETE CBC W/AUTO DIFF WBC (85025)',
                          '# COMPLETE BLOOD COUNT CBC (W/ DIFF PLT) - 6399','AUTO BLOOD COUNT - 1392 (F)','Blood Count WBC only with Diff','Complete Blood Count w/Manual Diff','Complete Blood Count w/Manual Differential','Complete Blood Count Test (CBC): leukocytes','xxComplete Blood Count (CBC)','CBC No Diff (Complete Blood Count):','Complete Blood Count/Auto Diff',
                          'COMPLETE BLOOD COUNT With / DIFF','Complete Blood Count w/ Automated Differential','BLOOD COUNT; OTHER THAN SPUN HEMATOCRIT','BLOOD COUNT PLATELET AUTOMATED (85049)','Complete Blood Count-Supergrps','BLOOD COUNT; SPUN MICROHE','Blood Count Diff Wbc.Lab (ABN $24.90)','WHITE BLOOD COUNT WITH DIFF','BLOOD COUNT; HEMOGRAM&PLATELET COUNT AUTOMATED',
                          'COMPLETE BLOOD COUNT STAT','White Blood Count w Differential Careset','BLOOD COUNT; HEMATOCRIT (','s COMPLETE BLOOD COUNT CBC','HL  Complete Blood Count 11081','LAB BLOOD COUNT WHITE BLOOD(ABN: $23.75)-85048','* Complete Blood Count (CBC) - IO','CBC Complete Blood Count with Manual Diff (CLH 1360)','Complete Blood Count without Differential',
                          'Blood Count Complete With Auto Differential','BLOOD COUNT; HEMO/PLATELET COMPLETE','Complete Blood Count w Differential Careset 85025','COMPLETE BLOOD COUNT NO DIFF','White Blood Count w Differential Careset 85004','Complete Blood Count w Diff','Complete Blood Count w/Manual Differential 85027','Complete Blood Count (No Diff)','Lab Blood Count Hematocrit (ABN $22.65)',
                          'Complete Blood Count (CBC)','AUTOMATED BLOOD COUNT','Complete Blood Count w/ Auto Diff.- (GC)','COMPLETE BLOOD COUNT W/DIFFERENTIAL AND PLT','COMPLETE BLOOD COUNT^','CBC NO Diff (Complete Blood Count)','Complete Blood Count w/o Differential','COMPLETE BLOOD COUNT & DIFF (CBC)','BLOOD COUNT AUTO CBC WITH DIFFERENTIAL','Automated blood complete blood count (hemogram) panel',
                          'COMPLETE BLOOD COUNT W/AUTO DIFF CBC W/AUTO DIFF','CBC Complete Blood Count','BLOOD COUNT; COMPLETE (CBC) AUTOMATED (HGB HCT RBC WBC AND PLATELET COUNT) AND AUTOMATED DIFFERENTIAL WBC COUNT','Quick Blood Count','BLOOD COUNT HEMOGRAM/PLATELET COUNT AUTO/AUTO COMP','General health panel This panel must include the following: Comprehensive metabolic panel (80053) Blood count complete (CBC) automated and automated differential WBC count (85025 or 85027 and 85004) OR Blood count complete (CBC) automated (85027) and',
                          'BLOOD COUNT; RETICULOCYTE MANUAL','BLOOD COUNT;RETICULOCYTE AUTOMATED','BLOOD COUNT HEMOGLOBIN','PRENATAL COMPLETE BLOOD COUNT','CBC- NO DIFF (COMPLETE BLOOD COUNT) (85027)','COMPLETE BLOOD COUNT - xCBC (I)','Complete Blood Count Test (CBC): white blood cell count','COMPLETE BLOOD COUNT - CBC (I)','COMPLETE BLOOD COUNT W/ DIFFERENTIAL (85025)','CBC - Complete Blood Count',
                          'BLOOD COUNT; COMPLETE (CBC) AUTOMATED','COMPLETE BLOOD COUNT/PLATELET (NO DIFF)','BLOOD COUNT COMPL AUTO CBC','COMPLETE BLOOD COUNT No / DIFF','Blood count; complete (CBC) automated (Hgb Hct RBC WBC and platelet count)','Complete Blood Count without Differential. (Labcorp)','Complete Blood Count w/ Platelets and Differential','Complete Blood Counts','Blood count; reticulocyte automated','COMPLETE BLOOD COUNT W/O','IH Complete Blood Count (CBC)','BLOOD COUNT RETICULOCYT','BLOOD COUNT; HEMATOCRIT','~# COMPLETE BLOOD COUNT CBC (W/ DIFF PLT) - 6399',
                          'Complete Blood Count with Differential','BLOOD COUNT;HEMATOCRIT','Complete Blood Count w Man Diff','Complete Blood Count-manual Diff','BLOOD COUNT AUTOMATED DIFF WBC (85004) 6399','CBC COMPLETE BLOOD COUNT W/O DIFF','Low Blood Counts','Automated Blood Count (CLH 0365)','COMPLETE BLOOD COUNT W/PLT','ONCOLOGY COMPLETE BLOOD COUNT','Complete Blood Count Test (CBC): cbc','BLOOD COUNT HEALTH FAIR-HIE','WHITE BLOOD COUNT^','COMPLETE BLOOD COUNT W/ DIFF','BLOOD COUNT AUTOMATED DIFF WBC (85004)','COMPLETE BLOOD COUNT - 1048 (F)','Complete Blood Count Test (CBC): wbcs',
                          'Complete Blood Count Test (CBC): platelet count','Complete Blood Count Test (CBC): hematocrit','COMPLETE BLOOD COUNT (CBC) WITH DIFFERENTIAL COUNT (85025)','Complete Blood Count (85025)','Complete Blood Count w/Man Diff','COMPLETE BLOOD COUNT W/DIFF','IH-Blood Count - Hemoglobin','BLOOD COUNT; HEMOGLOBIN (Hgb)','Complete Blood Count w Differental','WHITE BLOOD COUNT','COMPLETE BLOOD COUNT w DIFF (CBC)','Complete Blood Count Auto Diff','CBC COMP BLOOD COUNT AUTO DIFF','BLOOD COUNT; AUTOMATED DIFFERENTIAL WBC COUNT','CBC With Diff / Complete Blood Count','White Blood Count Manual Diff',
                          '85018 Hemoglobin Blood Count','CBCI COMPLETE BLOOD COUNT W/ DIFF','BLOOD COUNT;HEMOGRAM/PLATELETCOUNTAUTO','Blood count; hemoglobin','CBC Complete Blood Count #5463 (85025)','Complete blood count (CBC) without differential','Complete Blood Count W/Diff - CBC (J)','Complete Blood Count w/o Diff','COMPLETE BLOOD COUNT','Routine Blood Count','Complete Blood Count Test (CBC): platelets','CBC Complete Blood Count #5463','Complete Blood Count Test (CBC): blood count','Complete Blood Count w/Differential','CBC COMP BLOOD COUNT AUTO DIFF (DRMC)','CBC - COMPLETE BLOOD COUNT*','Lab Blood Count Hematocrit (ABN $19.55)','Complete Blood Count  ML','DISCONTINUED - COMPLETE BLOOD COUNT (85025)',
                          'Complete Blood Count w/o Indicies','Blood count; platelet automated','Lab Blood Count Hematocrit (ABN $25.55)','Complete Blood Count Test (CBC): thrombocytes','BLOOD COUNTWBCAUTOMATED','BLOOD COUNT AUTO CBC','Lab Blood Count Hematocrit','Complete Blood Count w/ Auto Differential','T Cell Subsets','T CELLABSOLUTE COUNT','TB TEST CELL IMMUN MEAS','T Cell PCR Gene Rearrange Fresh Spec','T CELLS; T4 AND T8 INCLUD','TB TEST CELL MEDIATED IMM MEASUREMENT OF GAMMA INT','T Cells 4/8','T CELL SUBSET ZTCSU','Full T Cell Subset','LYMPHOCYTE T CELL RATIO','T cell Receptor (TCR) Gene Rea','T CELL RECEPTOR (TCR) BETA GENE REARRANG PCR [ Q91446 ]',
                          'TB TEST CELL IMMUN MEASURE -quantiferon GOLD (86480)','T Cell Receptor Rearrange 83122','T Cells Tot Cnt','T CELL SUBSETS(NON-T','Lymphocytes T Cell Subsets','T CELL ABSOLUTE COUNT/RATIO','T CELL SUBSET PANEL (T4/T8 RATIO)','T Cells Total Count','T cells; total count','TB TEST Cell Immun Measure (QuantiFeron-Gold) (86480)','Tb Test Cell Immun Measure','T CELL CLONALITY PANEL (TCRB TCRG) PCR','TB TEST CELL IMMUN MEASURE (86480)','LYMPH ENUMERATION T CELL','T & B CELLS TOTAL','PLATELET AB CELL-BD(8937)','T & B Cell Subsets (86360)','TB CELL MEDIATED ANTIGN RESPNSE GAMMA INTERFER','.B Cell Panel Final Report','T SUBSET & B CELL QUANT','.B Cell Panel Results','FISH B Cell CLL',
                          'TB CELL MEDIATED IMM','T&B CELL QN BY FLOW CYTOMETRY [TBlood BankS]','T & B Cell QN by Flow Cyto','T and B Cells Subsets','T and B Cells with Subsets','B CELL GENE REARRANGEMENT QL PCR LEUMETA(R)','T & B Cell Enumeratin','Tb Cell Mediated Antign Respnse Gamma In','B CELL CLONALITY PANEL (IGH IGK) PCR','B Cells Tot Cnt','T AND B CELLSTOTAL','TB CELLULAR BLOOD TEST','B Cells Kappa','LAB Cell Count+Diff Synov Fld','T AND B CELLS TOTAL - 39588','NEO B Cell Gene Molecular','T and B cells','FISHB CELL LYMPHOCYTIC LEUKEMIA PANEL','Lab Cell Count Misc Body Fluid (ABN $33.25)','T and B Cell Quant By Flow Cytometry','B Cells Lambda','T&B Cell Quant By Flow Cytometry','LAB CELL COUNT W DIFFERENTIAL-89051','T B CELL FLOW CYTOMETRY',
                          'B CELLS TOTAL COUNT','T and B CELLS TOTAL','Lab Cell Count Misc Body Fluid','LYMPH SUBSET PN TB & NK CELLS','c T AND B NK CELL ENUMERATION','CD57 CD3 CD8 FLOW CYTOMETRY - 19860','CD8 PERCENT','CD8 COUNT','CD8','CD57CD3CD8 FLOW CYTOMETRY','CD8-/CD57+Lymphocytes','CD57 CD3 CD8 FLOW CYTOMETRY','T-CELL ACTIVATION CD8 SUBSETS','CD8 Immunohistochemistry ea  (88342AP)','CD57 CD3 CD8 FLOW$CYTOMETRY','*CBC/D CMP CD4 Ct  HIV VL & RPR 1-2 weeks before next OV','LYMPH CD4/CD9 COUNT','i  -Lymphocyte T Cell Subset Panel 4 CD4 CD8','CD4/CD8/T CELLS PANEL','CD4/CD8 CELL COUNT WITH RATIO','CD4 COUNT T CELLS ABSOLUTE (86361) 8360','c CD4/CD8 Count','CD4 T-LYMPH',
                          'CD4CD8 Ratio Profile - 505271','CD4 Abs','CD4/CD8 PANEL','CD4 COUNT LYMPHOCYTE SUBSET PANEL 5 ( 8730 )','T-Cell total count (CD4)','CD4/CD8 Ratio Profile   505271','CD48AM-HIE','CELLS ABSOLUTE CD4 COUNT-LYMPHOCYTE SUBSET PANEL 5 [Q 8360] (86361)','TCELL SUBSET PANEL CD4/CD8 TCSET',
                          'Cd4+ Cell Count <200 Cells/Mm','T CELL CD4 & CD8 & RATIO','CD4/CD8 Ratio Profile ( L)','CD4/T-HELPER CELL PROFILE','*HELPER/SUPPRESSOR CD4/CD8 SUBSET PANEL (86359)','DISCONTINUED - CD4 COUNT (86361)','LYMPHOCYTE CD4 COUNT','CD4/CD8      DRAW MON-THURS','LYMPHOCYTE SUBSET PANEL 5 CD4',
                          'UML - CD4/CD8 RATIO (86360) UHC MISC ORDER LYMPHOCYTE SUBSET PANEL4','Absolute CD4 Count','*CBC/D CMP CD4 Ct & HIV VL1-2 weeks before next OV','T Cells Cd4 And Cd8 Count (ABN $235.40)','CD4 COUNT LYMPHOCYTE SUBSET PANEL 5','cd4:cd8 (lymphocyte subset panel 4)','CD4 COUNT (8360) (86361)',
                          'CD4 / CD8 COUNT (86360)','CD4/CD8 Ratio Profile 505271','CD4/CD8 SUBSET PANEL + RATIO (86360)','C - CD4/CD8 WITH CD3','CD4 CELL COUNT (86361)','DISCONTINUED - CD4 COUNT','*CBC/D BMP CD4 Ct  HIV VL & RPR 1-2 weeks before next OV','T CELLS ABSOLUTE CD4 COUNT (86361)','DISCONTINUED - CELLS ABSOLUTE CD4 COUNT-LYMPHOCYTE SUBSET PANEL 5 [Q 8360] (86361)','T CELLS ABSOLUTE CD4','CD4 ABSOLUTE'
                          ,'CD4 CD8 Monitor (86360)','UML - CD4/CD8 RATIO (86360)','CD4/CD8 RATIO (86360)','CD4 Absolute Count','Flow Cytometry T-Helper Cells (CD4)','CD4 PANEL','Lymphocytes T Cell CD4/CD8 Subsets','CD4 Helper T Lymph','l CD43 10868N','CD4 (86361)','(SLN) T Cell Profile CD4 and CD8',
                          'T Cells Absolute Cd4&cd8 Cnt Ratio','(86361) CD4 count','CD4:CD8 Ratio Profile (LabCorp)','DISCONTINUED - CD4/CD8 SUBSET PANEL + RATIO (86360)','CD4:CD8 Ratio Profile','(LC) Helper T-Lymph-CD4','CD4 T-CELL COUNT','i  -Lymphocyte T-Cell Subset Panel 4 (CD4/CD8)','CD4 (Outside Lab) (86361)',
                          'CD4/CD8 (IMMUNE DEF)','CD4 T CELL SUBSET','CD4 Cell Count - 11026','CD4**  TC 8360X','CD4/CD8 SUBSET PANEL (86360)','LYMPH QUANT CD3/CD4 RATIO','Helper T-Lymphocyte Marker CD4 505008','HELPER SUPPRESSER (CD4 CT)','*CBC/D CD4 Ct HIV VL & CMP in 4 weeks','CD4 CD8Abs','DISCONTINUED - CD4 (86361)',
                          'CD4CD8CD3','T-HELPER CELLS (CD4) COUNT','CD4 CD8 Ratio','L - CD4/CD8 Ratio Profile','Absolute CD4','CD4 T-Cell Count (Mayo TCD4)',
                          'LYMPHOCYTE SUBSET PANEL 4 cd4/8','CD4  Flow Cytometry T-Helper Cells','* CD4/CD8 Ratio Profile (LC)','CD4 \T\ CD8 ABS COUNT','CD4-CD8 RATIO PROFILE','CD4 CD8 Monitor(86360)','CD4 / CD8 Subset Panel (86360)','CD4/CD8 RATIO Quest 7924 3rd Party (86360)','CD4/RATI71','CD4/CD8 RATIO (86360) LABCORP 505271 3RD PARTY',
                          'CD4 Lymphocyte Subset Panel/Helper T-Lymphocyte Marker CD4','CD4:CD8 RATIO','T LYMPH SUBSET (CD4)','CD4 Followup','Cd4+ Cell Count + 500 Cells/Mm3','CD4 & CD8 LYMPHOCYTES','LC Helper T-Lymph-CD4','CD4/CD8-T LYMPH QUANT','CD4/CD8 Ratio Profile *L*M*','CD4/8 LYMPH SUBSET PANEL','DISCONTINUED - CD4 (Outside Lab) (86361)',
                          'DISCONTINUED - T CELLS ABSOLUTE CD4 COUNT (86361)','CD4 T HELPER.','CD4 8 3 19','CD4IHC WITH INTERPRETATION','Cd4+ Cell Count 200 - 499 Cells/Mm (hiv)','CD4.CD8','*CD4 Count - HELPER/SUPPRESSOR CD4/CD8 SUBSET PANEL (86359)','CD4','CD4-Helper T Cell','CD4 LYMPHOCYTES ZCD4','LYMPHO PAN 1-CD4 ABS CNT ONLY',
                          'L - T-Helper (CD4 Lymph) - 505078','*CD4 Ct-HELPER/SUPPRESSOR CD4/CD8 SUBSET PANEL (86359)','*HELPER/SUPPRESSOR CD4/CD8 SUBSET PANEL','cd4 (lymphocyte subset panel 5)',
                          'T CELLS; ABSOLUTE CD4 COUNT','CD4 ABSOLUTE AND PERCENT','LYMPHOCYTES T-HELPER CELLS (CD4)','Lymphocyte Subset CD4 Panel 5 TSUB5','T Cells Cd4 And Cd8 Count','HL  Hiv Cd4','CD483 19NK','LYMPHOCYTE SUBSET PANEL 5 (ABSOLUTE LYMPHOCYTES %CD4 ABSOLUTE CD4)','Helper T-Lymph-CD4','CD4 LEVELS',
                          'CD4 ONLY LYMPHOCYTE SUBSET PANEL 5','T CELL CD4 &CD8 + RATIO','CD4/CD8 RATIO PROFILE','*HELPER/SUPPRESSOR CD4/CD8 SUBSET PANEL (86360)','CD4CD8 Ratio Profile','CD4/CD8 Count (86360)','Helper T-Lymphocyte Marker CD4','CD4 ENUMERATION','Helper Lymph CD4 (Sendout)','CD4  CD8 Lymphocytes','CD4/CD8 COUNT','LC CD4/CD8 Ratio Profile','Absolute CD4 Count (86361)','CD4/CD8 SUBSET PANEL* (86360)',
                          'CD45 (LEUKOCYTE COMMON$ANTIGEN) IHC','*CBC/D BMP CD4 Ct & HIV VL1-2 weeks before next OV','CD4 Cell Absolute COunt','CD4 CD8 ABSOLUTE','CD4 PERCENT','C - CD4/CD8 ENUMERATION','UML - CD4/CD8 RATIO (86360) UHC MISC ORDER LYMPHOCYTE SUBSET PANEL 4','CD4 ABSOLUTE COUNT ONLY','c CD4/CD8','T-CELLS CD4/CD8 BY FLOW CYTOMETRY','CD4 CD8 Monitor','T-HELPER (CD4 Lymph)','Absolute CD4 Flowsheet','(8360) CD4 count','c CD4/CD8 LYMPHOCYTES',
                          'CD4-CD8','CD4/CD8','Helper T - Lymph - CD4 - 505008','CD4  ABSOLUTE COUNT','Lymphocyte T Cell Subset Panel 4 CD4 / CD8 TSUB4','CD4 ABSOULTE COUNT','T Cells Cd4 Count','L - Helper T-Lymph-CD4','CD4 COUNT','Hiv Cd4','CD4 Profile','T-HELPER CELLS CD4/CD8 %','CD4 T Lymphocytes','DISCONTINUED -  CD4 COUNT (86361)','OHL - CD4 T-Cell Count-Mayo(Southlake Only)','DISCONTINUED - CD4 COUNT T CELLS ABSOLUTE (86361) 8360',
                          'CD4 SURFACE MARKER T CELLS','T Cell (CD4CD8)','CD4/CD8 with Ratio','CD4 COUNT (86361)','CD4 count (86360)','LYMPHOCYTE SUBSET CD4/CD8 PANEL','CD4 Panel (Helper/Inducer)  505008','l T HELPER (CD4) 4553','LYMPHOCYTEST CELL CD4/CD8 SUBSETS','HELPER T-LYMPH. MARKER CD4','DISCONTINUED - CD4 CELL COUNT (86361)','LYMPHOCYTE SUBSETS (CD4)')
or trim(lower(name)) like '%cbc%' or trim(lower(name)) like '%white blood%' 
or trim(lower(name)) like '%t cell%' 
or trim(lower(name)) like '%b cell%' or trim(lower(name)) like '%nk cell%')
and (trim(lower(status)) in ('active','administered','complete','final','in progress','ordered','pending','preliminary','resulted','reviewed','',' ')))

/////filtering only Tecfi patients
Create table sandbox.tbl_biogen_order_EHR_ALC_DK_ID  as
Select A.*, case when pat.ZIP3 is null then trim(A.patient_suffix)
            else trim(A.patient_suffix)||pat.ZIP3 end as Patient_ID
from sandbox.tbl_biogen_order_EHR_ALC_DK A
Inner join rwd.patients pat on A.genpatientid = pat.genpatientid
//////////////////////////////
drop table sandbox.tbl_biogen_order_EHR_ALC_DK_ID1
create table sandbox.tbl_biogen_order_EHR_ALC_DK_ID1 as
Select * from sandbox.tbl_biogen_order_EHR_ALC_DK_ID
where patient_ID in ( select distinct patient_ID from sandbox.tbl_biogen_tecfi_combined_DK_ID1  )


---joing the above date with EHR Results table----
create table sandbox.tbl_biogen_order_EHR_ALC_DK_ID2 as
select 
trim(b.genpatientid) as genpatientid,
trim(b.orderid) as orderid,
trim(b.panel) as panel,
trim(b.performeddttm) as Perform_Date,
trim(b.recordeddttm) as Record_Date,
trim(b.refrange) as Reference,
trim(b.resultstatus) as resultstatus,
trim(b.resultdttm) as resultdttm,
trim(b.test) as test,
trim(b.units) as units,
trim(b.value_x) as Value,
trim(b.errorflag) as errorflag,
trim(a.cpt4) as cpt4,
trim(a.encounterid) as encounterid,
trim(a.hcpcs) as hcpcs,
trim(a.inserted_date) as order_inserted_date,
trim(a.name) as name,
trim(a.orderdttm) as orderdttm,
trim(a.recordeddttm) as recordeddttm,
trim(a.rectype) as rectype,
trim(a.status) as status,
trim(a.patient_suffix) as patient_suffix,
trim(a.patient_ID) as patient_ID
from rwd.results b
inner join sandbox.tbl_biogen_order_EHR_ALC_DK_ID1 a on trim(a.genpatientid) = trim(b.genpatientid) 
                                                    and trim(a.orderid) = trim(b.orderid)
where (trim(lower(b.resultstatus)) not in ('canceled','cancelled','entered in error','rejected'))
and (upper(trim(b.errorflag))<>'Y')

//////looking extra data in results table

Create table sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp2 as
      select trim(b.genpatientid) as genpatientid,
      trim(b.orderid) as orderid,
      trim(b.panel) as panel,
      trim(b.performeddttm) as Perform_Date,
      trim(b.recordeddttm) as Record_Date,
      trim(b.refrange) as Reference,
      trim(b.resultstatus) as resultstatus,
      trim(b.resultdttm) as resultdttm,
      trim(b.test) as test,
      trim(b.units) as units,
      trim(b.value_x) as Value,
      trim(b.errorflag) as errorflag
      from rwd.results b 
      
      where (trim(lower(b.resultstatus)) not in ('canceled','cancelled','entered in error','rejected'))
      and (trim(b.errorflag)<>'Y')
      and (trim(lower(test)) like '%lymph%' or trim(lower(test)) like '%cd%' or trim(lower(test)) like '%t cell%' or trim(lower(test)) like '%b cell%'
      or trim(lower(test)) like '%nk cell%' or trim(lower(test)) like '_ly%' or trim(lower(test)) like '%lym%' or trim(lower(test)) like '%lymphocyte%'
      
      or trim(lower(b.panel)) like '%lymph%' or trim(lower(b.panel)) like '%cd%' or trim(lower(b.panel)) like '%t cell%' or trim(lower(b.panel)) like '%b cell%'
      or trim(lower(b.panel)) like '%nk cell%' or trim(lower(b.panel)) like '_ly%' or trim(lower(b.panel)) like '%lym%' or trim(lower(b.panel)) like '%lymphocyte%'
      
      ) 
      
Create table sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp3 as
select A.*, B.Patientsuffix as Patient_Suffix
from sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp2 A
inner join rwd.mappingdata b on A.genpatientid = B.genpatientid;

     
Create table sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp4 as
select A.*,case when pat.ZIP3 is null then trim(a.patient_suffix)
                  else trim(a.patient_suffix)||pat.ZIP3 end as Patient_ID 
from sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp3 A
inner join rwd.patients pat on A.genpatientid = pat.genpatientid;

Create table sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp5 as
select * from sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp4   
where trim(Patient_ID) in (select Patient_ID from sandbox.tbl_biogen_tecfi_combined_DK_ID1) 
     
     
Create table sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp6 as
select trim(b.genpatientid) as genpatientid,
      trim(b.orderid) as orderid,
      trim(b.panel) as panel,
      trim(b.Perform_Date) as Perform_Date,
      trim(b.Record_Date) as Record_Date,
      trim(b.Reference) as Reference,
      trim(b.resultstatus) as resultstatus,
      trim(b.resultdttm) as resultdttm,
      trim(b.test) as test,
      trim(b.units) as units,
      trim(b.Value) as Value,
      trim(b.errorflag) as errorflag,
      trim(a.cpt4) as cpt4,
      trim(a.encounterid) as encounterid,
      trim(a.hcpcs) as hcpcs,
      trim(a.inserted_date) as inserted_date,
      trim(a.name) as name,
      trim(a.orderdttm) as orderdttm,
      trim(a.recordeddttm) as recordeddttm,
      trim(a.rectype) as rectype,
      trim(a.status) as status,
      trim(b.patient_suffix) as patient_suffix,
      b.Patient_ID as Patient_ID
from sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp5 b
inner join rwd.orders a on b.genpatientid = a.genpatientid
                              and a.orderid = b.orderid



//////combining both the tables
drop table sandbox.tbl_biogen_EHR_ALC_DK_ID;
create table sandbox.tbl_biogen_EHR_ALC_DK_ID as
(
  Select * from sandbox.tbl_biogen_order_EHR_ALC_DK_ID2
  union 
  select * from sandbox.tbl_Biogen_Result_EHR_ALC_DK_ID1_temp6 
);

///////////deleting extra data where values are string///////
drop table sandbox.tbl_biogen_EHR_ALC_DK_ID1;
create table sandbox.tbl_biogen_EHR_ALC_DK_ID1 as
select * from sandbox.tbl_biogen_EHR_ALC_DK_ID
where (lower(trim(Value)) not in ('-','(note)','(received in preservative)','(sent in preservative)','*','* trace','* moderate','* positive','* small','** this patient has voluntarily submitted to a blood screen program offered by conemaugh health','*****','*screen negative*','*trace','*trace-intact','.','+','++','+++','a pos','abnormal','about 250','about 50','absent','adeq','adequate','amber','amorphous','amorphous sediment','arterial','arterialline','asc','auto','auto diff','autod','automated','automated diff','automated differential','bacteria','black','blood','bloody','brown','c&s indicated','calcium oxalate','canceled','cancelled','cancprov','cath','cath indwelling','cath straight','caucasian','cc','ccms','cerebrospinal fluid','cervical','cldy','clean catch','clean catch urine','clear','clear urn','clear yellow','cloud','cloudy','clr','colorless','comment','comment:','complete','criteria for review not met','csf','culture indicated - results to follow','cultured','dark yello','dark yellow','decreased','dk yellow','dkyellow','dnr','dnrtnp','done','duplicate request','enterococcus species','equivocal','escherichia coli','fasting','few','few mucous threads','few threads','final','final report','full field','gram negative rods','green','gross amt','hazy','heavy','hem','hemolyzed trace','hyaline','hyaline casts','hypochromia.','imaging study','immune','impression/conclusion below','increased','indicated','information not given','insufficient data','klebsiella pneumoniae','large','large 3+','large (+++)','large (3+)','large amount','leftradial','lg','light','light yellow','light yellow- straw','light-yellow','lt yel','lt yellow','lt. yellow','mand','manual','manual diff','manual differential','many','many motile','marked','micro','microbiology results','microscopic follows if indicated.','microscopic to follow','midstream','midstream urine','misty','mixed skin flora','mod','moderate','moderate 2+','moderate (++)','moderate (2+)','moderate amount','moderate mucous threads','n','n/a','na','neg','neg.','negative','negative (-)','negative for intraepithelial lesion or malignancy','negative for intraepithelial neoplasia or malignancy','negative/normal','ng','no','no antibodies detected','no comment','no comments','no culture indicated','no growth','non hemolyzed trace','non reac','non reactive','none','none detected','none seen','non-hemolyzed trace','nonreactive','non-reactive','norm','normal','normal dilute','normal morph.','normocytic/normochromic','not applicable','not calculated','not detected','not done','not given','not indic.','not indicated','not indicated.','not measured','not observed','not performed','not present','not provided','not reported','not required','not seen','not specified','note','note:','np','null','o','o pos','o positive','occ','occ/hpf','occasional','orange','other','packed','packed field','pale yellow','passed','pending','performed','plasma','platelets appear normal.','platelets confirmed by estimate.','plts normal','pos','positive','positive (+)','preliminary report','present','presumptive negative','qns','r','random','random urine','rare','reactive','red','report','request credited duplicate request','request credited pt unable to collect specimen. will return.','result below','result corrected','review confirms diff','reviewed','rh (d) negative','rh(d) positive','rightradial','routine','routine exam','s','scldy','see below','see below:','see comment','see comments','see detail','see fn','see message','see note','see note.','see note:','see notes','see protein confirmation','see report','see results below','see scanned result','see separate report','see text','see warde lab','send out','serum','siemens','sl','sl cloudy','sl hazy','slcloudy','slight','slight cloudy','slightly cloudy','slightly hazy','slightly-cloudy','slt','slt.cloudy','sm','small','small 1+','small (+)','small (1+)','small amount','speckled','sprcs','stool','straw','test canceled','test not performed','test not performed.','this specimen has reflexed to a urine culture.','this specimen will not reflex to a urine culture.','throat','tnp','tntc','too numerous to count','tr','trace','trace - intact','trace - lysed','trace (+-)','trace (20 mg/dl)','trace (non-hemolyzed)','trace-intact','trace-intacted','trace-lysed','transparent','turbid','ultrasound','unk','unknown','urinalysis results are not indicative of infection. culture not performed.','urine','urine culture ordered and plated','urine clean catch','urine clean catch outpatient','urine-voided','v76.2 ; screening for malignant neoplasm of the cervix','vaginal','variation in rbc size.','ventilator','verified','void','voided','voided urine','white','whole blood','within normal limits','wnl','xyxyxy','y','yel','yellow','yellow and clear','yellow clear','yellow/clear','yes')
and (trim(upper(Value)) not like 'EVAL%')
and (trim(Value)<>'0')
and (trim(patient_suffix) not like 'XXX -%' and trim(patient_suffix) is not null and trim(patient_suffix) not like ''))
;

///////////deleting extra data where test not matches/////
drop table sandbox.tbl_biogen_EHR_ALC_DK_ID2;
create table sandbox.tbl_biogen_EHR_ALC_DK_ID2 as
select * from sandbox.tbl_biogen_EHR_ALC_DK_ID1
where (lower(trim(test)) like '%lym%' or
      lower(trim(test)) like '%t cell%' or
      lower(trim(test)) like '%b cell%' or
      lower(trim(test)) like '%natural killer cell%' or
      lower(trim(test)) like '%nk%' or
      lower(trim(test)) like '%cd%')
      and lower(trim(test)) not in ('blast cells #','target cell','hemoglobin cds','granulocytes absolute cds','rdw cds','pathologist provided icd9:','mcv cds','cs volume rcd','hematocrit cds','mchc cds','icd9 code','monocytes absolute cds','mch cds','wbc cds','granulocytes % cds','monocytes % cds','rbc cds','plt cds')
      ;
//
Drop table sandbox.tbl_biogen_EHR_ALC_DK_ID3;
create table sandbox.tbl_biogen_EHR_ALC_DK_ID3 as
select * from sandbox.tbl_biogen_EHR_ALC_DK_ID2
where lower(trim(Value)) not in ('< 0.80','<0.6','<0.8','<0.91','<1','<1.0','<1:1','<1:4','<20','1+','2+','0')
;


////////////////////////////////////////looking for WBC & lymphocyte % in the table.///////////////
Select Distinct test from sandbox.tbl_biogen_EHR_ALC_DK_ID1
where CPT4 in ('85004','85007','85009','85048')

Select * from sandbox.tbl_biogen_EHR_ALC_DK_ID1
where name = 'WBC Count and Differential' 

Select distinct reference from sandbox.tbl_biogen_EHR_ALC_DK_ID1
where lower(trim(test)) = 'lymphocyte'
order by 1


////////Creating table for WBC and Lymphocyte %
Create table sandbox.tbl_biogen_lymph_WBC_Lym_DK as
Select A.Patient_suffix, A.Patient_ID, A.Recordeddttm, A.GenpatientID, A.EncounterID, A.CPT4, A.Name, A.Panel, A.Test, A.Value, A.units, A.reference
 ,B.CPT4 as Lym_CPT4, B.Name as lym_name, B.Panel as lym_panel, B.Test as lym_test, B.Value as lym_value, B.units as lym_units, B.reference as lym_reference
 from
(Select Patient_suffix, Patient_ID, Recordeddttm, GenpatientID, EncounterID, CPT4, Name, Panel, Test, Value,units,reference
 from sandbox.tbl_biogen_EHR_ALC_DK_ID1
 Where  trim(lower(test)) in ('zz-wbc total count','white cell count','white cell cnt','white cell blood count','white blood count','white blood cells','white blood cell(wbc)count','white blood cell countwbc','white blood cell count*','white blood cell count',
                              'white blood cell (wbc) count','white blood cell','wbcss','wbc-p','wbc-m','wbc-inst.count','wbc-at10','wbc18','wbc. - wbc.','wbc.','wbc**','wbc*','wbc(act2)','wbc whole blood','wbc csf','wbc count','wbc cds','wbc 2 decimals',
                              'wbc @ crown','wbc (white blood count)','wbc (white blood cell count)','wbc (uc)','wbc (nbim)','wbc (nbfp)','wbc (lnfm)','wbc (l)','wbc (cim)','wbc (aim)','wbc (act2)','wbc (act)','wbc (900419319)','wbc (1800)','wbc ( leukocytes )',
                              'wbc - imh','wbc - 005025','wbc -','wbc','uho wbc','q white blood cell count','nucleated rbc/100wbc','nrbc/100wbc','lab wbc','hwbc','(n) white blood cell','%wbc')
        or trim(lower(test)) like '# of wbc%'
) A
inner join 
(Select Patient_suffix, Patient_ID, Recordeddttm, GenpatientID, EncounterID, CPT4, Name, Panel, Test, Value,units,reference
 from sandbox.tbl_biogen_EHR_ALC_DK_ID1
 Where  trim(lower(test)) in ('total lymphocytes%','lymphs% -','lymph %auto','lymph%','lymph% - auto count','lymph manual %','total lymphocytes %','lym %','lym%','lymph % hk','lymphocytes (%)','lymph % (nbfp)','lymph percent auto','lym% (uc)','lymph percent',
                              'lymphocytes % (manual)','lymph %','lym(%)','lymphs% (act2)','lymphocyte %','lymphocyte auto percent','lymphocytes % cds','lymphocyte % auto diff','lymphs%-','% lymphocytes auto','lymphs %','lym % lnfm','%lymph','_%lym','lymphocytes %',
                              'lym% -','lymph % (auto)','csf lymphocytes % (tube 1)','%lymphocytes','% lymph','lymphocytes percent man','(n) lymphocytes % (auto)','lymphocyte% (manual)','lymphs%','__lymph%','lymph % (cim)','lymphocytes percent',
                              'lymph % whole blood','% lymphocytes','lymphocyte% (auto)','lymph % (nbim)','lymp%','lymph % (aim)','ih lymph%','lymph% auto lh','lymphocytes % - lymph%','lym%**','%lymph %','lymphocyte % auto','%atypical lymph','%lymph x 10','%lyms',
                              'atyp lymph percent man','atypical lymphocyte percent','ih atyp lym%','lymphocyte count percentage','lymphocytes manual%','lymphocytes % (auto)','lymphocyte')
        and reference not in ('0.4-3.3','0.7-3.8','1.0-3.8','1.0-4.0','1.0-5.0','1.2-5.4')
) B
on A.genpatientid = B.Genpatientid and A.encounterID = B.encounterID




Create table sandbox.tbl_biogen_lymph_WBC_Lym_DK_1 as
select * from sandnox.tbl_biogen_lymph_WBC_Lym_DK
where lym_units not in ('K/mm3','K/uL','grams per deciliter')
    and lym_value <> 1.5


Drop table sandbox.tbl_biogen_EHR_ALC_DK_ID2_1

Create table sandbox.tbl_biogen_EHR_ALC_DK_ID2_1 as
select * from sandbox.tbl_biogen_EHR_ALC_DK_ID1
where lower(trim(name)) in ('absolute lymphocyte count')
    or lower(trim(panel)) in ('lymphocyte subset panel 5 (absolute lymphocytes %cd4 absolute cd4)','absolute lymphocyte count','absolute lymphocyte count')
    or lower(trim(test)) in ('lymphocytes absolute','lymphs abs','lymphocyte abs auto','absolute lymphs','lymphocyte absolute number','lymphocyte absolute flow','abs lymphocyte','abs lymphs','abs lymphocytes','abs lymphs (a)','lymphocyte count absolute','absolute lymphocyte ct','absolute lymphocytes','lymph abs man','lymphocytesabsolute','absolute lymphocytes (30002110)','lymphocytes absolute cds','lymp abs','lymphocyte #abs','lymphocytes absolute count','abs lymphs','lymphs (absolute)','lymphs (absolute) (l115255)','abs. lymph ct.','lymph absolute','lymphs (absolute) (l)','asolute lymph(nbfp)','abs lymphs','lymph abs #','lymphocytes-abs','atypical lymphocyte absolute','abs lymphocytes','absolute lymphocytes (manual)','absolute lymphocyte','lymphs (absolute)','lymphocytes absolute man','lymphocytes - abs (man)','abs lymphocytes','lymphocytes(absolute)','absolute lymph','lymphs (absolute) (l015917)','lymphocytes (absolute)','abs. lymphocytes (act)','lympocyte absolute','absolute lymphocytes','lymphocytesabs.','absolute lymphs','absolute lymphocytes#','lymph absolute calculated','absolute lymph','absolute reactive lymphocytes','abs. atyp lymph','abs. lymphocytes','lym(abs)','lymphocyte abs.','lymph absolute','lymphocyte (abs)','lymphocyte absolute #','lymph abs auto','lymphocyte - absolute count','lymphocytes absolute','lymphocytes abs. #','lymphocytesabsolute','lym abs','absol lymph','lymphocyte abs','absolute lymphocyte ct','lymphocyte absolute','lymphocytes absolute auto','abs lymph','absolute lymphocyte count','abs large lymphs','lymphocyte abs #','absolute lymphocyte count std calculation','lymphs (absolute) - 015917','absolute lymph:','absolute lymphocyte','lymphocyte absolute count','lymphocyte absolute','lymphs (absolute)','abs lymph','abs lymph','q absolute lymphocytes','abs. lymphocytes','lymphocytes absolute calculated','lymphs (abs)','lymph abs','absolute lymph ct','lymphocyte#absolute','absolute lymphocytes*','lymph    abs','lymphocytesabs. calculated','atypical lymphocytes-abs','lymph absolute #:','abs. lymph','lymphs absolute','absolute lymph count','abs.cd19+ lymphs',
                            'lymphocyte#','lymphocytes manual diff','lymphocytes - lymph.','lymphocyte (auto)','absolute reactive lymphocytes','q lymphocytes','lymphocytes*','reactive lymphocyte #','lymphocytes(act)','lymphocytes (a)','lymphocytes (30001800)','lymphocytes automated','lymphocytes #','lymphocytes manual#','reactive lymphocytes','atypical lymphocytes','lymphocyte normal','lymphocyte manual','# lymphocytes','lymphocytes relative auto','lymphocyte variant body fluid','lymphocytes:','prolymphocyte#','fluid lymphocytes','lymphocyte #','atyp lymphocytes','reactive lymphocytes (manual)','lymphocytes % (auto)','lymphocytes # (auto)','lymphocytes whole blood','lymphocytesfluid','lymphocytes','lymphocyte normal body fluid','lymphocytes - tube 4','lymphocyte','lymphocyte count','lymphocytes (#)','lymphocytes percent auto','(n) lymphocytes # (auto)','lymphocytes relative diff','atypical lymphocyte')

drop table sandbox.tbl_biogen_EHR_ALC_DK_ID3_1

create table sandbox.tbl_biogen_EHR_ALC_DK_ID3_1 as
select * from sandbox.tbl_biogen_EHR_ALC_DK_ID2_1
where lower(trim(Value)) not in ('< 0.80','<0.6','<0.8','<0.91','<1','<1.0','<1:1','<1:4','<20','1+','2+','0')
;

drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_ID

Create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_ID as
select A.*, dateadd(dd,-90,start_date) as ALC_strt_Date 
from sandbox.tbl_biogen_tecfi_combined_DK_ID1 A;

Alter table sandbox.tbl_biogen_EHR_ALC_DK_ID3_1
add column multiplying_Factor number

Create table sandbox.lym_units_reference1 (REFERENCE varchar(), UNITS varchar(), Multiply_factor number)

Update sandbox.tbl_biogen_EHR_ALC_DK_ID3_1 A
set A.multiplying_Factor = B.Multiply_factor
from sandbox.lym_units_reference1 B
where A.REFERENCE = B.reference
    and A.UNITS = B.UNITS

Update sandbox.tbl_biogen_EHR_ALC_DK_ID3_1 A
set A.multiplying_Factor = B.Multiply_factor
from sandbox.lym_units_reference1 B
where A.REFERENCE = B.reference
    and A.multiplying_Factor is null

Update sandbox.tbl_biogen_EHR_ALC_DK_ID3_1 A
set A.multiplying_Factor = 11
where reference in ('10.0-50.0 %', '20-45','10.0-50.0')

Update sandbox.tbl_biogen_EHR_ALC_DK_ID3_1 A
set A.multiplying_Factor = 1
where reference in ('1000-3500')

Update sandbox.tbl_biogen_EHR_ALC_DK_ID3_1 A
set A.multiplying_Factor = 1000
where units in ('K/CMM', 'x10^3/ul','K/uL','x10E3/uL')

Create table sandbox.tbl_biogen_EHR_ALC_DK_ID3_1_1 as
Select * from sandbox.tbl_biogen_EHR_ALC_DK_ID3_1
where multiplying_factor <> 11

Drop table sandbox.tbl_biogen_EHR_ALC_DK_ID3_2

Create table sandbox.tbl_biogen_EHR_ALC_DK_ID3_2 as
 Select A.*, (cast (A.value as float) * A.multiplying_Factor) as Final_value 
 from sandbox.tbl_biogen_EHR_ALC_DK_ID3_1_1 A



Drop table sandbox.tbl_biogen_lymph_WBC_Lym_DK

Create table sandbox.tbl_biogen_lymph_WBC_Lym_DK as
Select distinct A.Patient_suffix, A.Patient_ID, A.Recordeddttm, A.GenpatientID, A.EncounterID, A.CPT4, A.Name, A.Panel, A.Test, A.Value, A.units, A.reference
 ,B.CPT4 as Lym_CPT4, B.Name as lym_name, B.Panel as lym_panel, B.Test as lym_test, B.Value as lym_value, B.units as lym_units, B.reference as lym_reference
 from
(Select Patient_suffix, Patient_ID, Recordeddttm, GenpatientID, EncounterID, CPT4, Name, Panel, Test, Value,units,reference
 from sandbox.tbl_biogen_EHR_ALC_DK_ID1
 Where  trim(lower(test)) in ('zz-wbc total count','white cell count','white cell cnt','white cell blood count','white blood count','white blood cells','white blood cell(wbc)count','white blood cell countwbc','white blood cell count*','white blood cell count',
                              'white blood cell (wbc) count','white blood cell','wbcss','wbc-p','wbc-m','wbc-inst.count','wbc-at10','wbc18','wbc. - wbc.','wbc.','wbc**','wbc*','wbc(act2)','wbc whole blood','wbc csf','wbc count','wbc cds','wbc 2 decimals',
                              'wbc @ crown','wbc (white blood count)','wbc (white blood cell count)','wbc (uc)','wbc (nbim)','wbc (nbfp)','wbc (lnfm)','wbc (l)','wbc (cim)','wbc (aim)','wbc (act2)','wbc (act)','wbc (900419319)','wbc (1800)','wbc ( leukocytes )',
                              'wbc - imh','wbc - 005025','wbc -','wbc','uho wbc','q white blood cell count','nucleated rbc/100wbc','nrbc/100wbc','lab wbc','hwbc','(n) white blood cell','%wbc')
        or trim(lower(test)) like '# of wbc%'
) A
inner join 
(Select Patient_suffix, Patient_ID, Recordeddttm, GenpatientID, EncounterID, CPT4, Name, Panel, Test, Value,units,reference
 from sandbox.tbl_biogen_EHR_ALC_DK_ID1
 Where  trim(lower(test)) in ('total lymphocytes%','lymphs% -','lymph %auto','lymph%','lymph% - auto count','lymph manual %','total lymphocytes %','lym %','lym%','lymph % hk','lymphocytes (%)','lymph % (nbfp)','lymph percent auto','lym% (uc)','lymph percent',
                              'lymphocytes % (manual)','lymph %','lym(%)','lymphs% (act2)','lymphocyte %','lymphocyte auto percent','lymphocytes % cds','lymphocyte % auto diff','lymphs%-','% lymphocytes auto','lymphs %','lym % lnfm','%lymph','_%lym','lymphocytes %',
                              'lym% -','lymph % (auto)','csf lymphocytes % (tube 1)','%lymphocytes','% lymph','lymphocytes percent man','(n) lymphocytes % (auto)','lymphocyte% (manual)','lymphs%','__lymph%','lymph % (cim)','lymphocytes percent',
                              'lymph % whole blood','% lymphocytes','lymphocyte% (auto)','lymph % (nbim)','lymp%','lymph % (aim)','ih lymph%','lymph% auto lh','lymphocytes % - lymph%','lym%**','%lymph %','lymphocyte % auto','%atypical lymph','%lymph x 10','%lyms',
                              'atyp lymph percent man','atypical lymphocyte percent','ih atyp lym%','lymphocyte count percentage','lymphocytes manual%','lymphocytes % (auto)','lymphocyte percent','lymphocytes relative percent','lymphocyte',
                             'lymphocyte#','lymphocytes manual diff','lymphocytes - lymph.','lymphocyte (auto)','absolute reactive lymphocytes','q lymphocytes','lymphocytes*','reactive lymphocyte #','lymphocytes(act)','lymphocytes (a)','lymphocytes (30001800)',
                              'lymphocytes automated','lymphocytes #','lymphocytes manual#','reactive lymphocytes','atypical lymphocytes','lymphocyte normal','lymphocyte manual','# lymphocytes','lymphocytes relative auto','lymphocyte variant body fluid','lymphocytes:',
                              'prolymphocyte#','fluid lymphocytes','lymphocyte #','atyp lymphocytes','reactive lymphocytes (manual)','lymphocytes % (auto)','lymphocytes # (auto)','lymphocytes whole blood','lymphocytesfluid','lymphocytes','lymphocyte normal body fluid',
                              'lymphocytes - tube 4','lymphocyte','lymphocyte count','lymphocytes (#)','lymphocytes percent auto','(n) lymphocytes # (auto)','lymphocytes relative diff','atypical lymphocyte')
        and reference not in ('0.4-3.3','0.7-3.8','1.0-3.8','1.0-4.0','1.0-5.0','1.2-5.4')
) B
on A.genpatientid = B.Genpatientid and A.encounterID = B.encounterID

Select Distinct lym_reference, lym_units from sandbox.tbl_biogen_lymph_WBC_Lym_DK

Create table sandbox.tbl_biogen_lymph_WBC_Lym_DK_1 as
select * from sandbox.tbl_biogen_lymph_WBC_Lym_DK
where lym_reference not in ('0','<=0.0','0.0-0.0','0.00-25.00','0.6-4.1','0.7-4.3','0.80-3.10 K/ul','0.8-3.5','0.8-4.0','0.90 - 5.20','0.9-3.0','1.00-4.00','1.0-3.0','1.0-3.5','1.0-3.7','1.0-4.2','1.0-4.8','1.0-5.5','1.0-5.9','1.2 - 3.9','1.2-3.4','1.2-3.6','1.2-3.7','1.2-3.9','1.3-2.9','1.5-3.4','1.5-3.9','1.5-4.0')

Create table sandbox.tbl_biogen_lymph_WBC_Lym_DK_2 as
Select 
      GENPATIENTID,
      null as ORDERID,
      null as PANEL,
      null as PERFORM_DATE,
      null as RECORD_DATE,
      REFERENCE,
      null as RESULTSTATUS,
      null asRESULTDTTM,
      TEST,
      UNITS,
      VALUE,
      null as ERRORFLAG,
      CPT4,
      ENCOUNTERID,
      null as HCPCS,
      null as ORDER_INSERTED_DATE,
      NAME,
      null as ORDERDTTM,
      RECORDEDDTTM,
      null as RECTYPE,
      null as STATUS,
      PATIENT_SUFFIX,
      PATIENT_ID,
      null as MULTIPLYING_FACTOR,
      (cast(VALUE as float) * cast(lym_value as float)) FINAL_VALUE
from sandbox.tbl_biogen_lymph_WBC_Lym_DK_1


Create table sandbox.tbl_biogen_EHR_ALC_DK_ID3_WBC as
(
  select * from sandbox.tbl_biogen_EHR_ALC_DK_ID3_2
  union 
  select * from sandbox.tbl_biogen_lymph_WBC_Lym_DK_2
)




//adding Practice fusion data 
Create table sandbox.tbl_ALC_practice_fusion_DK
(GENPATIENTID VARCHAR(16777216),
ORDERID VARCHAR(16777216),
PANEL VARCHAR(16777216),
PERFORM_DATE VARCHAR(16777216),
RECORD_DATE VARCHAR(16777216),
REFERENCE VARCHAR(16777216),
RESULTSTATUS VARCHAR(16777216),
RESULTDTTM VARCHAR(16777216),
TEST VARCHAR(16777216),
UNITS VARCHAR(16777216),
VALUE VARCHAR(16777216),
ERRORFLAG VARCHAR(16777216),
CPT4 VARCHAR(16777216),
ENCOUNTERID VARCHAR(16777216),
HCPCS VARCHAR(16777216),
ORDER_INSERTED_DATE VARCHAR(16777216),
NAME VARCHAR(16777216),
ORDERDTTM VARCHAR(16777216),
RECORDEDDTTM VARCHAR(16777216),
RECTYPE VARCHAR(16777216),
STATUS VARCHAR(16777216),
PATIENT_SUFFIX VARCHAR(16777216),
PATIENT_ID VARCHAR(16777216),
MULTIPLYING_FACTOR NUMBER,
FINAL_VALUE Float
)


create table sandbox.tbl_ALC_practice_fusion_DK_final as
(
Select * from sandbox.tbl_biogen_EHR_ALC_DK_ID3_WBC
union 
select * from sandbox.tbl_ALC_practice_fusion_DK
)



-------logic started for part2 ---------
///adding new column in the Tecfi table for first refill,last refill, 30days prior to refill

drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID;

Create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID as
select A.*, dateadd(dd,-90,start_date) as ALC_strt_Date 
from sandbox.tbl_biogen_tecfi_combined_DK_ID1 A
where trim(A.patient_suffix) in (select distinct patient_suffix from sandbox.tbl_biogen_tecfi_combined_DK_ID11_30);////change the table name in the subquery part for various condition of 15

/////overlap of ALC patients in EHR data with Claims patient with 90 days prior to first refill of Tecfidera
drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID1;	

Create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID1 as 
Select A.* from sandbox.tbl_ALC_practice_fusion_DK_final A
inner join sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID B on A.patient_suffix = B.patient_suffix 
                                                     and A.recordeddttm between B.ALC_strt_Date and B.start_date;

select Count (distinct patient_suffix) from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID1;

///////////////////////////////////////////Part 3//////////////
        ////adding days_supply to end_Date for ALC end
drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart3_contb;

Create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart3_contb as
Select A.*, B.ALC_end_date from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID A
left join 
(Select patient_suffix, 
    case when days_supply is null then end_Date else dateadd(dd,(case when days_supply is null then 0 else days_supply end),end_Date) end as ALC_end_date
    from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID 
    where end_date = service_date) B on A.patient_suffix = B.patient_suffix;
	


////////////////////////Part 4//////////////////////////////////////

        ////////Adding 90 days in end_date + days_supply
drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart4_contb;

Create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart4_contb as
Select A.*, dateadd(dd,90,ALC_end_date) as ALC_end_date_discont from sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart3_contb A
;
///////patients with availability of ALC assessment >3 months post discon
drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID3;

create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID3 as
select A.* from sandbox.tbl_ALC_practice_fusion_DK_final A
inner join sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart4_contb B on trim(A.patient_suffix) = trim(B.patient_suffix) 
                                                     and A.recordeddttm >= B.ALC_end_date_discont
where trim(A.patient_suffix) in (select distinct patient_suffix from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID1 ) 
    and (A.value is not null or trim(A.value) not in ('0', ''));

select Count (distinct patient_suffix) from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID3;


////////////////////////Part 5//////////////////////////////////////

        ////////Adding 90 days in end_date + days_supply

drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart5_contb;

Create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart5_contb as
Select A.*, dateadd(dd,60,ALC_end_date) as ALC_end_date_discont_60 from sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart4_contb A;

///////patients with availability of ALC assessment >2 months post discon
drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID4;

create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID4 as
select A.* from sandbox.tbl_ALC_practice_fusion_DK_final A
inner join sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart5_contb B on trim(A.patient_suffix) = trim(B.patient_suffix) 
                                                     and A.recordeddttm >= B.ALC_end_date_discont_60
where trim(A.patient_suffix) in (select distinct patient_suffix from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID1 ) 
    and (A.value is not null or trim(A.value) not in ('0', ''));

select Count (distinct patient_suffix) from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID4;


///////////////////////Part 6/////////////////////////////////////////////////////
        ////patients with availability of ALC assessment post discontinuation
drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID5;

create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID5 as
select A.* from sandbox.tbl_ALC_practice_fusion_DK_final A
inner join sandbox.tbl_biogen_tecfi_combined_DK_ALC_IDpart5_contb B on trim(A.patient_suffix) = trim(B.patient_suffix) 
                                                     and A.recordeddttm >= B.ALC_end_date
where trim(A.patient_suffix) in (select distinct patient_suffix from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID1 ) 
    and (A.value is not null or trim(A.value) not in ('0', ''));

////////patients with availability of ALC assessment post discontinuation and post 3 months
drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID6;

create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID6 as
select A.* from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID5 A
where trim(A.patient_suffix) in (select distinct patient_suffix from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID3 ) 
    and (A.value is not null or trim(A.value) not in ('0', ''));
///////patients with availability of ALC assessment post discontinuation and post 3 month + 2 ALC
drop table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID7;

create table sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID7 as
select patient_suffix,count(distinct encounterid) as ALC_Count from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID6 
group by patient_suffix
having count(distinct encounterid) > 1;

select count( distinct patient_suffix) from sandbox.tbl_biogen_tecfi_combined_DK_ALC_contb_ID7;

