import { Component, OnInit, NgModule } from '@angular/core';

@Component({
  selector: 'frontPage',
  templateUrl: './frontPage.component.html',
  styleUrls: ['./frontPage.component.scss']
})
export class FrontPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
