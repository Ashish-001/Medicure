import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mainLayout',
  templateUrl: './mainLayout.component.html',
  styleUrls: ['./mainLayout.component.scss']
})
export class MainLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
